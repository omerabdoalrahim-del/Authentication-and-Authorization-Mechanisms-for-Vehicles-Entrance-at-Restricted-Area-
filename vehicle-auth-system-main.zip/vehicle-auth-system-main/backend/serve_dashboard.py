"""
Simple server to serve dashboard.html 
Run this with: python serve_dashboard.py
"""
from flask import Flask, send_from_directory
from flask_cors import CORS

app = Flask(__name__, static_folder='..')
CORS(app)

@app.route('/')
@app.route('/dashboard.html')
def serve_dashboard():
    return send_from_directory('..', 'dashboard.html')

@app.route('/<path:filename>')
def serve_static(filename):
    return send_from_directory('..', filename)

if __name__ == '__main__':
    print("=" * 60)
    print("🌐 Dashboard Server Starting...")
    print("📂 Serving dashboard.html from parent directory")
    print("🔗 Open: http://localhost:8080/dashboard.html")
    print("=" * 60)
    app.run(host='0.0.0.0', port=8080, debug=True)
