"""
PHASE 5: Production Configuration
Uvicorn + Gunicorn for High Concurrency
"""
import multiprocessing

# ASGI Server Configuration
bind = "0.0.0.0:5000"
worker_class = "uvicorn.workers.UvicornWorker"

# Concurrency: Multiple workers for handling simultaneous requests
workers = multiprocessing.cpu_count() * 2 + 1  # Recommended formula
worker_connections = 1000
max_requests = 1000
max_requests_jitter = 50

# Timeouts
timeout = 30
keepalive = 5

# Logging
accesslog = "logs/access.log"
errorlog = "logs/error.log"
loglevel = "info"

# Security
limit_request_line = 4096
limit_request_fields = 100

# Process naming
proc_name = "securegate_api"

# Graceful shutdown
graceful_timeout = 30

print(f"[PRODUCTION] Starting with {workers} workers")
print(f"[PRODUCTION] Worker connections: {worker_connections}")
print(f"[PRODUCTION] Max requests per worker: {max_requests}")
