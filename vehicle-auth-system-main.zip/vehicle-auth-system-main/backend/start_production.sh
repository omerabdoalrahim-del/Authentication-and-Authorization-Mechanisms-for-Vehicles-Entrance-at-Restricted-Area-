#!/bin/bash
# Production Startup Script
# PHASE 5: Runs backend with multiple workers

echo "=========================================="
echo "SecureGate Production Server"
echo "=========================================="

# Create logs directory
mkdir -p logs

# Export environment
export PYTHONPATH=$PYTHONPATH:$(pwd)

# Number of workers (default: auto-detect based on CPU cores)
WORKERS=${WORKERS:-$(python -c "import multiprocessing; print(multiprocessing.cpu_count() * 2 + 1)")}

echo "Starting with $WORKERS workers..."

# Run with Gunicorn + Uvicorn workers
gunicorn phase1_app:app \
    --config gunicorn_config.py \
    --workers $WORKERS \
    --worker-class uvicorn.workers.UvicornWorker \
    --bind 0.0.0.0:5000 \
    --timeout 30 \
    --graceful-timeout 30 \
    --keep-alive 5 \
    --access-logfile logs/access.log \
    --error-logfile logs/error.log \
    --log-level info

echo "Server stopped."
