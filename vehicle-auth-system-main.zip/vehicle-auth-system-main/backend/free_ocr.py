"""
FREE LOCAL OCR using EasyOCR - NO API COSTS!

This replaces the OpenRouter API with a local OCR solution that:
- Runs on your computer
- 100% FREE forever
- No internet required
- No subscription
- Unlimited scans!
"""

import easyocr
import cv2
import numpy as np
from io import BytesIO
import base64
from PIL import Image

# Initialize EasyOCR reader (only once at startup)
print("🔄 Loading FREE OCR model...")
reader = easyocr.Reader(['en'], gpu=False)  # Use CPU (free!)
print("✅ FREE OCR ready!")

def scan_license_plate_free(image_data):
    """
    FREE OCR scanning using EasyOCR
    
    Args:
        image_data: Base64 encoded image data
    
    Returns:
        dict: {'text': plate_number, 'message': status, 'quality': confidence}
    """
    try:
        # Remove data URL prefix if present
        if image_data.startswith('data:'):
            image_data = image_data.split(',')[1]
        
        # Decode base64 to image
        image_bytes = base64.b64decode(image_data)
        image = Image.open(BytesIO(image_bytes))
        
        # Convert PIL to numpy array for EasyOCR
        img_array = np.array(image)
        
        # Convert RGB to BGR for OpenCV
        if len(img_array.shape) == 3:
            img_array = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
        
        print("[FREE OCR] Scanning image...")
        
        # Run OCR
        results = reader.readtext(img_array)
        
        if not results:
            print("[FREE OCR] ⚠️ No text detected")
            return {
                'text': 'NOPLATE',
                'message': 'No plate visible',
                'quality': 'NONE'
            }
        
        # Extract text from results and filter for license plates
        detected_texts = []
        for (bbox, text, conf) in results:
            # Clean text: remove spaces and special chars
            clean_text = ''.join(c for c in text.upper() if c.isalnum())
            
            # License plates are usually 5-10 characters
            if 4 <= len(clean_text) <= 10 and conf > 0.3:
                detected_texts.append((clean_text, conf))
                print(f"[FREE OCR] Found: '{clean_text}' (confidence: {conf:.2f})")
        
        if detected_texts:
            # Get the best match (highest confidence)
            best_plate = max(detected_texts, key=lambda x: x[1])
            plate_number = best_plate[0]
            confidence = best_plate[1]
            
            print(f"[FREE OCR] ✅ SUCCESS: {plate_number} (conf: {confidence:.2f})")
            
            return {
                'text': plate_number,
                'message': f'Detected: {plate_number}',
                'quality': 'DETECTED'
            }
        else:
            print("[FREE OCR] ⚠️ No valid plate found")
            return {
                'text': 'NOPLATE',
                'message': 'No valid plate detected',
                'quality': 'NONE'
            }
            
    except Exception as e:
        print(f"[FREE OCR] ❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return {
            'text': 'NOPLATE',
            'message': f'OCR error: {str(e)}',
            'quality': 'ERROR'
        }
