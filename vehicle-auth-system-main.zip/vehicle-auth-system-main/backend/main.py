from fastapi import FastAPI, Depends, HTTPException, File, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime, timedelta
from typing import Optional
import os
from dotenv import load_dotenv
from passlib.context import CryptContext
from jose import JWTError, jwt

from models import Base, User, Vehicle, AccessLog, VehicleType, AccessStatus
from anpr import ANPRProcessor

load_dotenv()

# Database Configuration
DATABASE_URL = os.getenv('DATABASE_URL')
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Security
SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-change-this')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 1440  # 24 hours

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Initialize FastAPI
app = FastAPI(
    title="SecureGate ANPR System",
    description="Production-Grade Vehicle Authentication System",
    version="2.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize ANPR Processor (singleton)
anpr_processor = None

@app.on_event("startup")
async def startup():
    global anpr_processor
    print("[FastAPI] Creating database tables...")
    Base.metadata.create_all(bind=engine)
    print("[FastAPI] Initializing ANPR processor...")
    anpr_processor = ANPRProcessor()
    print("[FastAPI] ✓ System ready!")

# Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ==================== AUTHENTICATION ====================

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
):
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid credentials")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    return user

def require_admin(current_user: User = Depends(get_current_user)):
    if current_user.role != "ADMIN":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

# ==================== ROUTES ====================

@app.get("/")
async def root():
    return {
        "service": "SecureGate ANPR System",
        "version": "2.0.0",
        "status": "operational"
    }

# Admin: Login
@app.post("/api/auth/login")
async def login(username: str, password: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == username).first()
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = create_access_token(data={"sub": user.username})
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {"username": user.username, "role": user.role}
    }

# Admin: Register Vehicle (PROTECTED)
@app.post("/api/admin/vehicle")
async def register_vehicle(
    plate_number: str,
    owner_name: str,
    vehicle_type: VehicleType,
    expiry_date: Optional[str] = None,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """
    CRITICAL: Plate number normalization happens HERE
    """
    # Normalize plate: uppercase, remove spaces and special chars
    normalized_plate = plate_number.upper().replace(" ", "").replace("-", "")
    
    print(f"[ADMIN] Registering vehicle: '{plate_number}' -> '{normalized_plate}'")
    
    # Check if already exists
    existing = db.query(Vehicle).filter(Vehicle.plate_number == normalized_plate).first()
    if existing:
        raise HTTPException(status_code=409, detail=f"Plate '{normalized_plate}' already registered")
    
    # Create vehicle
    vehicle = Vehicle(
        plate_number=normalized_plate,
        owner_name=owner_name,
        vehicle_type=vehicle_type,
        expiry_date=datetime.fromisoformat(expiry_date) if expiry_date else None,
        created_by=current_user.id
    )
    
    db.add(vehicle)
    db.commit()
    db.refresh(vehicle)
    
    return {
        "success": True,
        "vehicle": {
            "id": vehicle.id,
            "plate": vehicle.plate_number,
            "owner": vehicle.owner_name,
            "type": vehicle.vehicle_type
        }
    }

# Admin: List Vehicles
@app.get("/api/admin/vehicles")
async def list_vehicles(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == True).all()
    return {
        "vehicles": [{
            "id": v.id,
            "plate": v.plate_number,
            "owner": v.owner_name,
            "type": v.vehicle_type,
            "active": v.is_active,
            "expiry": v.expiry_date.isoformat() if v.expiry_date else None
        } for v in vehicles]
    }

# Admin: Deactivate Vehicle
@app.delete("/api/admin/vehicle/{vehicle_id}")
async def deactivate_vehicle(
    vehicle_id: int,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    
    vehicle.is_active = False
    db.commit()
    
    return {"success": True, "message": f"Vehicle {vehicle.plate_number} deactivated"}

# GATE: Scan and Authenticate
@app.post("/api/gate/scan")
async def gate_scan(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    MAIN AUTHENTICATION ENDPOINT
    Receives image, processes with ANPR, authenticates against database
    """
    print(f"\n[GATE] Scan request received: {file.filename}")
    
    # Read image bytes
    image_bytes = await file.read()
    
    # Process with ANPR
    result = anpr_processor.process(image_bytes)
    
    if not result["success"]:
        log_access(db, "ERROR", 0.0, "ANPR processing failed")
        return {
            "status": "DENIED",
            "reason": "Image processing failed",
            "detected_text": result.get("error", "Unknown error")
        }
    
    detected_plate = result["plate"]
    confidence = result["confidence"]
    
    print(f"[GATE] ANPR Detected: '{detected_plate}' (Confidence: {confidence:.2f})")
    
    # Low confidence check
    if confidence < 0.6:
        log_access(db, detected_plate, confidence, "Low confidence score")
        return {
            "status": "DENIED",
            "reason": "Low Confidence - Try Again",
            "detected_text": detected_plate,
            "confidence": confidence
        }
    
    # Normalize for database lookup
    normalized = detected_plate.replace(" ", "").upper()
    
    # Query database
    vehicle = db.query(Vehicle).filter(
        Vehicle.plate_number == normalized,
        Vehicle.is_active == True
    ).first()
    
    # DECISION MATRIX
    if not vehicle:
        print(f"[GATE] ✗ DENIED - Not registered")
        log_access(db, normalized, confidence, "Not Registered")
        return {
            "status": "DENIED",
            "reason": "Not Registered",
            "detected_text": detected_plate
        }
    
    # Check visitor expiry
    if vehicle.vehicle_type == VehicleType.VISITOR:
        if vehicle.expiry_date and vehicle.expiry_date < datetime.utcnow():
            print(f"[GATE] ✗ DENIED - Visitor expired")
            log_access(db, normalized, confidence, "Visitor Access Expired", vehicle=vehicle)
            return {
                "status": "DENIED",
                "reason": "Visitor Access Expired",
                "detected_text": detected_plate,
                "owner": vehicle.owner_name
            }
    
    # ACCESS GRANTED
    print(f"[GATE] ✓ ACCESS GRANTED for {vehicle.owner_name} ({vehicle.vehicle_type})")
    log_access(db, normalized, confidence, None, vehicle=vehicle, granted=True)
    
    return {
        "status": "GRANTED",
        "plate": vehicle.plate_number,
        "owner": vehicle.owner_name,
        "type": vehicle.vehicle_type,
        "confidence": confidence
    }

# Logs: Get recent access logs
@app.get("/api/logs")
async def get_logs(
    limit: int = 50,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    logs = db.query(AccessLog).order_by(AccessLog.timestamp.desc()).limit(limit).all()
    return {
        "logs": [{
            "timestamp": log.timestamp.isoformat(),
            "plate": log.plate_number_detected,
            "status": log.status,
            "owner": log.owner_name,
            "reason": log.rejection_reason,
            "confidence": log.confidence_score
        } for log in logs]
    }

# ==================== HELPER FUNCTIONS ====================

def log_access(db: Session, plate: str, confidence: float, reason: Optional[str], vehicle: Optional[Vehicle] = None, granted: bool = False):
    """
    IMMUTABLE AUDIT TRAIL
    Every scan attempt is logged
    """
    log = AccessLog(
        plate_number_detected=plate,
        status=AccessStatus.GRANTED if granted else AccessStatus.DENIED,
        confidence_score=confidence,
        rejection_reason=reason,
        vehicle_type=vehicle.vehicle_type if vehicle else None,
        owner_name=vehicle.owner_name if vehicle else "Unknown"
    )
    db.add(log)
    db.commit()

# ==================== INITIALIZATION ====================

# Create default admin user on first run
@app.on_event("startup")
async def create_default_admin():
    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.username == "admin").first()
        if not admin:
            admin = User(
                username="admin",
                password_hash=get_password_hash("admin123"),  # CHANGE THIS IN PRODUCTION
                role="ADMIN"
            )
            db.add(admin)
            db.commit()
            print("[FastAPI] ✓ Default admin created (admin/admin123)")
    finally:
        db.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
