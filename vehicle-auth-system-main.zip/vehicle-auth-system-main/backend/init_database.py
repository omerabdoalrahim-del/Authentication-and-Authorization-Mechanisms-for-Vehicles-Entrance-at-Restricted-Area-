"""
Initialize Supabase Database with Tables and Sample Data
Run this once to set up your database
"""
from app import app, db, Staff, Visitor
from datetime import datetime, timedelta

def init_database():
    print("=" * 60)
    print("INITIALIZING DATABASE")
    print("=" * 60)
    
    with app.app_context():
        # Drop all tables (fresh start)
        print("\n[1/3] Dropping existing tables...")
        db.drop_all()
        print("✓ Tables dropped")
        
        # Create all tables
        print("\n[2/3] Creating new tables...")
        db.create_all()
        print("✓ Tables created: Staff, Visitor, AccessLog")
        
        # Add sample staff vehicles
        print("\n[3/3] Adding sample data...")
        
        staff_vehicles = [
            {"name": "John Staff", "plate": "STF101"},
            {"name": "Mary Manager", "plate": "STF110"},
            {"name": "Bob Boss", "plate": "ST001"},
        ]
        
        for vehicle in staff_vehicles:
            staff = Staff(name=vehicle["name"], plate_number=vehicle["plate"])
            db.session.add(staff)
            print(f"  ✓ Added staff: {vehicle['name']} - {vehicle['plate']}")
        
        # Add sample visitor vehicles (expires in 7 days)
        expiry_date = datetime.utcnow() + timedelta(days=7)
        
        visitor_vehicles = [
            {"name": "Guest One", "plate": "VST101"},
            {"name": "Guest Two", "plate": "VST102"},
        ]
        
        for vehicle in visitor_vehicles:
            visitor = Visitor(
                name=vehicle["name"],
                plate_number=vehicle["plate"],
                expiry=expiry_date
            )
            db.session.add(visitor)
            print(f"  ✓ Added visitor: {vehicle['name']} - {vehicle['plate']} (expires: {expiry_date.date()})")
        
        # Commit all changes
        db.session.commit()
        
        print("\n" + "=" * 60)
        print("DATABASE INITIALIZED SUCCESSFULLY!")
        print("=" * 60)
        print("\nYou can now use these plates for testing:")
        print("\nSTAFF VEHICLES:")
        for v in staff_vehicles:
            print(f"  - {v['plate']}: {v['name']}")
        print("\nVISITOR VEHICLES:")
        for v in visitor_vehicles:
            print(f"  - {v['plate']}: {v['name']}")
        print("\n" + "=" * 60)

if __name__ == '__main__':
    init_database()
