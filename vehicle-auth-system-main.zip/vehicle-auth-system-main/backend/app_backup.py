from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError
from datetime import datetime
import os
from dotenv import load_dotenv
import base64
import re
import google.generativeai as genai

load_dotenv()

# Configure Gemini
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///vehicle_auth.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Models
class Staff(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    plate_number = db.Column(db.String(20), unique=True, nullable=False)
    status = db.Column(db.String(10), default='OUT')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Visitor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    plate_number = db.Column(db.String(20), unique=True, nullable=False)
    expiry = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(10), default='OUT')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AccessLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    plate_number = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(100))
    status = db.Column(db.String(20))
    reason = db.Column(db.String(200))

@app.route('/')
def serve_frontend():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/staff', methods=['GET', 'POST'])
def staff_routes():
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        
        if not name or not plate:
            return jsonify({'error': 'Name and plate number required'}), 400
            
        try:
            staff = Staff(name=name, plate_number=plate.upper())
            db.session.add(staff)
            db.session.commit()
            return jsonify({'success': True, 'id': staff.id}), 201
        except IntegrityError:
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    staff = Staff.query.all()
    return jsonify([{
        'id': s.id,
        'name': s.name,
        'plate': s.plate_number,
        'status': s.status
    } for s in staff])

@app.route('/api/staff/<int:staff_id>', methods=['DELETE'])
def delete_staff(staff_id):
    staff = Staff.query.get_or_404(staff_id)
    try:
        db.session.delete(staff)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@app.route('/api/visitors', methods=['GET', 'POST'])
def visitor_routes():
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        expiry = data.get('expiry')
        
        if not all([name, plate, expiry]):
            return jsonify({'error': 'All fields required'}), 400
            
        try:
            visitor = Visitor(
                name=name,
                plate_number=plate.upper(),
                expiry=datetime.fromisoformat(expiry.replace('Z', '+00:00'))
            )
            db.session.add(visitor)
            db.session.commit()
            return jsonify({'success': True, 'id': visitor.id}), 201
        except IntegrityError:
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    visitors = Visitor.query.all()
    return jsonify([{
        'id': v.id,
        'name': v.name,
        'plate': v.plate_number,
        'expiry': v.expiry.isoformat(),
        'status': v.status
    } for v in visitors])

@app.route('/api/visitors/<int:visitor_id>', methods=['DELETE'])
def delete_visitor(visitor_id):
    visitor = Visitor.query.get_or_404(visitor_id)
    try:
        db.session.delete(visitor)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@app.route('/api/process-vehicle', methods=['POST'])
def process_vehicle():
    data = request.get_json()
    plate = data.get('plate_number', '').upper().strip()
    direction = data.get('direction', 'IN')
    
    if not plate:
        return jsonify({'error': 'Plate number required'}), 400

    print(f"\n[AUTH] Processing plate: '{plate}' Direction: {direction}")
    
    # Search in Staff table
    vehicle = Staff.query.filter_by(plate_number=plate).first()
    is_visitor = False
    vehicle_type = "Staff"
    
    # If not found in Staff, search in Visitor
    if not vehicle:
        vehicle = Visitor.query.filter_by(plate_number=plate).first()
        is_visitor = True
        vehicle_type = "Visitor"

    # Print all registered vehicles for debugging
    if not vehicle:
        all_staff = Staff.query.all()
        all_visitors = Visitor.query.all()
        print(f"[AUTH] Vehicle NOT FOUND!")
        print(f"[AUTH] Registered Staff: {[s.plate_number for s in all_staff]}")
        print(f"[AUTH] Registered Visitors: {[v.plate_number for v in all_visitors]}")
        
        log_access('DENIED', plate, 'Unknown', 'Unauthorized Vehicle - Not Registered')
        return jsonify({
            'status': 'DENIED',
            'message': 'Unauthorized Vehicle - Not Registered',
            'name': 'Unknown'
        })

    print(f"[AUTH] Vehicle FOUND as {vehicle_type}: {vehicle.name}")

    timestamp = datetime.utcnow()
    
    # Check visitor expiry
    if is_visitor and vehicle.expiry < timestamp:
        print(f"[AUTH] Visitor access expired")
        log_access('DENIED', plate, vehicle.name, 'Visitor access expired')
        return jsonify({
            'status': 'DENIED',
            'message': 'Visitor access expired',
            'name': vehicle.name
        })

    # Check duplicate entry
    if direction == 'IN' and vehicle.status == 'IN':
        print(f"[AUTH] Vehicle already inside")
        log_access('DENIED', plate, vehicle.name, 'Vehicle is already inside')
        return jsonify({
            'status': 'DENIED',
            'message': 'Vehicle is already inside',
            'name': vehicle.name
        })

    # Check invalid exit
    if direction == 'OUT' and vehicle.status == 'OUT':
        print(f"[AUTH] Vehicle not inside")
        log_access('DENIED', plate, vehicle.name, 'Vehicle is not inside')
        return jsonify({
            'status': 'DENIED',
            'message': 'Vehicle is not inside',
            'name': vehicle.name
        })

    # GRANT ACCESS
    vehicle.status = direction
    db.session.commit()
    
    status = 'ENTRY GRANTED' if direction == 'IN' else 'EXIT RECORDED'
    reason = f'{vehicle_type} entering restricted area' if direction == 'IN' else f'{vehicle_type} leaving restricted area'
    
    print(f"[AUTH] ✅ {status} for {vehicle.name}")
    log_access(status, plate, vehicle.name, reason)
    
    return jsonify({
        'status': status,
        'message': reason,
        'name': vehicle.name
    })

@app.route('/api/access-logs', methods=['GET'])
def get_access_logs():
    logs = AccessLog.query.order_by(AccessLog.timestamp.desc()).limit(50).all()
    return jsonify([{
        'timestamp': log.timestamp.isoformat(),
        'plate': log.plate_number,
        'name': log.name,
        'status': log.status,
        'reason': log.reason
    } for log in logs])

@app.route('/api/ocr/scan', methods=['POST'])
def ocr_scan():
    data = request.get_json()
    image_data = data.get('image')
    
    if not image_data:
        return jsonify({'error': 'No image provided'}), 400

    try:
        if 'base64,' in image_data:
            image_data = image_data.split('base64,')[1]
            
        image_bytes = base64.b64decode(image_data)
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        response = model.generate_content([
            "Extract the license plate number. Return ONLY the plate text, nothing else. If no plate visible, return 'NO_PLATE'.",
            {'mime_type': 'image/jpeg', 'data': image_bytes}
        ])
        
        text = response.text.strip().upper()
        # Remove extra spaces but keep single spaces
        text = ' '.join(text.split())
        
        return jsonify({'text': text})
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    staff = Staff.query.all()
    return jsonify([{
        'id': s.id,
        'name': s.name,
        'plate': s.plate_number,
        'status': s.status
    } for s in staff])

@app.route('/api/staff/<int:staff_id>', methods=['DELETE'])
def delete_staff(staff_id):
    staff = Staff.query.get_or_404(staff_id)
    try:
        db.session.delete(staff)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@app.route('/api/visitors', methods=['GET', 'POST'])
def visitor_routes():
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        expiry = data.get('expiry')
        
        if not all([name, plate, expiry]):
            return jsonify({'error': 'All fields required'}), 400
            
        try:
            visitor = Visitor(
                name=name,
                plate_number=plate.upper(),
                expiry=datetime.fromisoformat(expiry.replace('Z', '+00:00'))
            )
            db.session.add(visitor)
            db.session.commit()
            return jsonify({'success': True, 'id': visitor.id}), 201
        except IntegrityError:
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    visitors = Visitor.query.all()
    return jsonify([{
        'id': v.id,
        'name': v.name,
        'plate': v.plate_number,
        'expiry': v.expiry.isoformat(),
        'status': v.status
    } for v in visitors])

@app.route('/api/visitors/<int:visitor_id>', methods=['DELETE'])
def delete_visitor(visitor_id):
    visitor = Visitor.query.get_or_404(visitor_id)
    try:
        db.session.delete(visitor)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@app.route('/api/access-logs', methods=['GET'])
def get_access_logs():
    logs = AccessLog.query.order_by(AccessLog.timestamp.desc()).limit(50).all()
    return jsonify([{
        'timestamp': log.timestamp.isoformat(),
        'plate': log.plate_number,
        'name': log.name,
        'status': log.status,
        'reason': log.reason
    } for log in logs])

@app.route('/api/ocr/scan', methods=['POST'])
def ocr_scan():
    data = request.get_json()
    image_data = data.get('image')
    
    if not image_data:
        return jsonify({'error': 'No image provided'}), 400

    try:
        if 'base64,' in image_data:
            image_data = image_data.split('base64,')[1]
            
        image_bytes = base64.b64decode(image_data)
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        response = model.generate_content([
            "Extract the license plate number. Return ONLY the plate text, nothing else. If no plate visible, return 'NO_PLATE'.",
            {'mime_type': 'image/jpeg', 'data': image_bytes}
        ])
        
        text = response.text.strip().upper()
        # Remove extra spaces but keep single spaces
        text = ' '.join(text.split())
        
        return jsonify({'text': text})
        
    except Exception as e:
        print(f"[OCR] Error: {e}")
        return jsonify({'error': str(e)}), 500

def log_access(status, plate, name, reason):
    log = AccessLog(
        timestamp=datetime.utcnow(),
        plate_number=plate,
        name=name,
        status=status,
        reason=reason
    )
    db.session.add(log)
    db.session.commit()

# NEW: OCR endpoint for automatic camera scanning
@app.route('/api/scan-plate', methods=['POST'])
def scan_plate():
    """
    Extract plate number from uploaded image using Gemini Vision API
    Used by automatic camera scanning
    """
    try:
        # Check if image was uploaded
        if 'plate_image' not in request.files:
            return jsonify({'error': 'No image uploaded'}), 400
        
        file = request.files['plate_image']
        
        if file.filename == '':
            return jsonify({'error': 'Empty filename'}), 400
        
        # Read image bytes
        image_bytes = file.read()
        
        print(f"\n[OCR] Processing image ({len(image_bytes)} bytes)...")
        
        # Convert to base64 for Gemini
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        # Call Gemini Vision API
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        prompt = """
        Extract ONLY the license plate number from this image.
        Return ONLY the alphanumeric plate text, nothing else.
        If no plate is visible, return: NO_PLATE
        Remove any spaces or special characters.
        Example responses: ABC123, STF110, VST101, NO_PLATE
        """
        
        response = model.generate_content([
            prompt,
            {'mime_type': 'image/jpeg', 'data': base64_image}
        ])
        
        detected_text = response.text.strip().upper()
        
        # Clean the text (remove spaces, special chars)
        plate_text = ''.join(c for c in detected_text if c.isalnum())
        
        print(f"[OCR] Gemini detected: '{detected_text}' -> Cleaned: '{plate_text}'")
        
        return jsonify({
            'text': plate_text,
            'confidence': 0.9  # Gemini doesn't provide confidence, use fixed value
        })
        
    except Exception as e:
        print(f"[OCR] Error: {e}")
        return jsonify({'error': str(e), 'text': 'NO_PLATE'}), 500

@app.route('/api/process-vehicle', methods=['POST'])
def process_vehicle():
    data = request.get_json()
    plate = data.get('plate_number', '').upper().strip()
    direction = data.get('direction', 'IN')
    
    if not plate:
        return jsonify({'error': 'Plate number required'}), 400

    print(f"\n[AUTH] Processing plate: '{plate}' Direction: {direction}")
    
    # Search in Staff table
    vehicle = Staff.query.filter_by(plate_number=plate).first()
    is_visitor = False
    vehicle_type = "Staff"
    
    # If not found in Staff, search in Visitor
    if not vehicle:
        vehicle = Visitor.query.filter_by(plate_number=plate).first()
        is_visitor = True
        vehicle_type = "Visitor"

    # Print all registered vehicles for debugging
    if not vehicle:
        all_staff = Staff.query.all()
        all_visitors = Visitor.query.all()
        print(f"[AUTH] Vehicle NOT FOUND!")
        print(f"[AUTH] Registered Staff: {[s.plate_number for s in all_staff]}")
        print(f"[AUTH] Registered Visitors: {[v.plate_number for v in all_visitors]}")
        
        log_access('DENIED', plate, 'Unknown', 'Unauthorized Vehicle - Not Registered')
        return jsonify({
            'status': 'DENIED',
            'message': 'Unauthorized Vehicle - Not Registered',
            'name': 'Unknown'
        })

    print(f"[AUTH] Vehicle FOUND as {vehicle_type}: {vehicle.name}")

    timestamp = datetime.utcnow()
    
    # Check visitor expiry
    if is_visitor and vehicle.expiry < timestamp:
        print(f"[AUTH] Visitor access expired")
        log_access('DENIED', plate, vehicle.name, 'Visitor access expired')
        return jsonify({
            'status': 'DENIED',
            'message': 'Visitor access expired',
            'name': vehicle.name
        })

    # Check duplicate entry
    if direction == 'IN' and vehicle.status == 'IN':
        print(f"[AUTH] Vehicle already inside")
        log_access('DENIED', plate, vehicle.name, 'Vehicle is already inside')
        return jsonify({
            'status': 'DENIED',
            'message': 'Vehicle is already inside',
            'name': vehicle.name
        })

    # Check invalid exit
    if direction == 'OUT' and vehicle.status == 'OUT':
        print(f"[AUTH] Vehicle not inside")
        log_access('DENIED', plate, vehicle.name, 'Vehicle is not inside')
        return jsonify({
            'status': 'DENIED',
            'message': 'Vehicle is not inside',
            'name': vehicle.name
        })

    # GRANT ACCESS
    vehicle.status = direction
    db.session.commit()
    
    status = 'ENTRY GRANTED' if direction == 'IN' else 'EXIT RECORDED'
    reason = f'{vehicle_type} entering restricted area' if direction == 'IN' else f'{vehicle_type} leaving restricted area'
    
    print(f"[AUTH] ✅ {status} for {vehicle.name}")
    log_access(status, plate, vehicle.name, reason)
    
    return jsonify({
        'status': status,
        'message': reason,
        'name': vehicle.name
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)