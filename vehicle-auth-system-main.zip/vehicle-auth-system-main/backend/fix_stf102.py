"""Fix STF102 - remove trailing spaces"""
from app import app, db, Staff

with app.app_context():
    # Find STF102 with spaces
    staff = Staff.query.filter(Staff.plate_number.like('STF102%')).first()
    
    if staff:
        print(f"Found: '{staff.plate_number}' (length: {len(staff.plate_number)})")
        staff.plate_number = staff.plate_number.strip()
        db.session.commit()
        print(f"✅ Fixed to: '{staff.plate_number}' (length: {len(staff.plate_number)})")
    else:
        print("❌ STF102 not found")
        
    # Also clean up those garbage plates (123, 100, nadia)
    garbage = Staff.query.filter(Staff.plate_number.in_(['123', '100'])).all()
    for g in garbage:
        db.session.delete(g)
    
    db.session.commit()
    print("\n✅ Cleaned up garbage plates")
    
    # Show all plates
    print("\nCLEAN DATABASE:")
    all_staff = Staff.query.all()
    for s in all_staff:
        print(f"  {s.plate_number} - {s.name}")
