"""
QUICK FIX: Add /api/scan-plate endpoint to existing app.py
This adds automatic camera OCR scanning
"""
# ADD THIS TO YOUR APP.PY AFTER THE /api/ocr/scan endpoint (around line 270)

@app.route('/api/scan-plate', methods=['POST'])
def scan_plate():
    """
    NEW: For automatic camera scanning
    Accepts image file upload and returns plate text
    """
    try:
        # Check for uploaded file
        if 'plate_image' not in request.files:
            return jsonify({'error': 'No image uploaded', 'text': 'NO_PLATE'}), 400
        
        file = request.files['plate_image']
        image_bytes = file.read()
        
        print(f"\n[AUTO-SCAN] Received image: {len(image_bytes)} bytes")
        
        # Use Gemini OCR
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content([
            "Extract ONLY the license plate number. Return just the text, nothing else. If no plate: NO_PLATE",
            {'mime_type': 'image/jpeg', 'data': base64_image}
        ])
        
        text = response.text.strip().upper()
        # Remove spaces
        text = ''.join(text.split())
        
        print(f"[AUTO-SCAN] Detected: '{text}'")
        
        return jsonify({'text': text, 'confidence': 0.9})
        
    except Exception as e:
        print(f"[AUTO-SCAN] Error: {e}")
        return jsonify({'error': str(e), 'text': 'NO_PLATE'}), 500
