"""
PHASE 1: FastAPI Backend with Database Integration
Authentication Logic Implementation
"""
from fastapi import FastAPI, Depends, HTTPException, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime
from typing import Optional
import os
from dotenv import load_dotenv

from database_models import Base, Staff, Visitor, AccessLog
from anpr import ANPRProcessor

load_dotenv()

# Database Configuration
DATABASE_URL = os.getenv('DATABASE_URL')
if not DATABASE_URL:
    raise ValueError("DATABASE_URL not found in .env file!")

print(f"[DB] Connecting to database...")
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Initialize FastAPI
app = FastAPI(
    title="Vehicle Authentication System - Production",
    description="ANPR-based Access Control with Database Integration",
    version="2.0.0"
)

# PHASE 5: CORS Security - Only allow specific domains
ALLOWED_ORIGINS = os.getenv('ALLOWED_ORIGINS', 'http://localhost:3000,http://localhost:3001').split(',')

print(f"[SECURITY] CORS allowed origins: {ALLOWED_ORIGINS}")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,  # Specific domains only in production
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE"],  # Only needed methods
    allow_headers=["*"],
)

# Initialize ANPR Processor
anpr_processor = None

@app.on_event("startup")
async def startup():
    global anpr_processor
    print("[PHASE 1] Initializing system...")
    
    # Create tables if they don't exist (mirrors existing structure)
    Base.metadata.create_all(bind=engine)
    print("[DB] ✓ Database tables ready")
    
    # Initialize ANPR
    anpr_processor = ANPRProcessor()
    print("[ANPR] ✓ ANPR processor ready")
    print("[PHASE 1] ✓ System operational!")

# PHASE 5: Database Dependency with Fail-Safe
def get_db():
    """
    CRITICAL: Fail-Closed Database Connection
    If database fails, the system DENIES access by default
    """
    db = SessionLocal()
    try:
        # Test connection on each request
        db.execute("SELECT 1")
        yield db
    except Exception as e:
        print(f"[FAIL-SAFE] Database connection error: {e}")
        print(f"[FAIL-SAFE] SYSTEM FAILING CLOSED - Default to DENY")
        db.close()
        raise HTTPException(
            status_code=503,
            detail={
                "status": "SYSTEM_ERROR",
                "message": "Database connection failed - System in fail-safe mode",
                "action": "DEFAULT_DENY"
            }
        )
    finally:
        db.close()

# ==================== PHASE 1: CORE ENDPOINT ====================

@app.post("/api/gate/check-access")
async def check_access(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    PHASE 1: THE BRAIN - Complete Authentication Logic
    
    Input: Image file
    Process:
        1. ANPR extracts plate text
        2. Sanitize: uppercase, remove spaces/special chars
        3. Query Vehicles table
        4. Apply decision logic
        5. Log EVERY request
    
    Output: JSON with status, owner, vehicle_type
    """
    print(f"\n{'='*60}")
    print(f"[GATE] New access request received")
    print(f"{'='*60}")
    
    # STEP 1: Read image
    image_bytes = await file.read()
    print(f"[STEP 1] Image received: {len(image_bytes)} bytes")
    
    # STEP 2: ANPR Processing
    print(f"[STEP 2] Calling ANPR processor...")
    anpr_result = anpr_processor.process(image_bytes)
    
    if not anpr_result["success"]:
        # Log failed ANPR attempt
        log_access_attempt(db, "ERROR", "Unknown", "DENIED", "ANPR processing failed")
        return {
            "status": "DENIED",
            "reason": "Image processing failed",
            "detected_text": anpr_result.get("plate", "ERROR")
        }
    
    detected_text = anpr_result["plate"]
    confidence = anpr_result.get("confidence", 0.0)
    print(f"[ANPR] Raw detection: '{detected_text}' (Confidence: {confidence:.2f})")
    
    # STEP 3: SANITIZE - Critical normalization
    # Remove ALL spaces, special characters, convert to uppercase
    sanitized = detected_text.upper()
    sanitized = ''.join(c for c in sanitized if c.isalnum())  # Only alphanumeric
    
    print(f"[STEP 3] Sanitized: '{detected_text}' → '{sanitized}'")
    
    if not sanitized or len(sanitized) < 3:
        log_access_attempt(db, sanitized, "Unknown", "DENIED", "Invalid plate format")
        return {
            "status": "DENIED",
            "reason": "Invalid plate detected",
            "detected_text": detected_text
        }
    
    # STEP 4: DATABASE QUERY
    print(f"[STEP 4] Querying database for plate: '{sanitized}'")
    
    # Check Staff table first
    vehicle = db.query(Staff).filter(Staff.plate == sanitized).first()
    vehicle_type = "STAFF"
    is_visitor = False
    
    # If not staff, check Visitor table
    if not vehicle:
        vehicle = db.query(Visitor).filter(Visitor.plate == sanitized).first()
        vehicle_type = "VISITOR"
        is_visitor = True
    
    # STEP 5: DECISION LOGIC
    print(f"[STEP 5] Applying decision matrix...")
    
    # CASE 1: Plate NOT FOUND
    if not vehicle:
        print(f"[DENIED] Plate '{sanitized}' NOT REGISTERED")
        log_access_attempt(db, sanitized, "Unknown", "DENIED", "Not Registered")
        return {
            "status": "DENIED",
            "reason": "Not Registered",
            "detected_text": detected_text,
            "plate_sanitized": sanitized
        }
    
    # CASE 2: Plate FOUND but check if active/valid
    owner_name = vehicle.name
    print(f"[FOUND] Vehicle: {owner_name} ({vehicle_type})")
    
    # CASE 3: For VISITORS - Check expiry
    if is_visitor:
        if vehicle.expiry < datetime.utcnow():
            print(f"[DENIED] Visitor access EXPIRED")
            log_access_attempt(db, sanitized, owner_name, "DENIED", "Visitor Access Expired")
            return {
                "status": "DENIED",
                "reason": "Visitor Access Expired",
                "owner": owner_name,
                "vehicle_type": vehicle_type,
                "detected_text": detected_text
            }
    
    # CASE 4: ACCESS GRANTED
    print(f"[GRANTED] ✓ Access APPROVED for {owner_name}")
    log_access_attempt(db, sanitized, owner_name, "GRANTED", f"{vehicle_type} vehicle authenticated")
    
    return {
        "status": "GRANTED",
        "owner": owner_name,
        "vehicle_type": vehicle_type,
        "plate": sanitized,
        "detected_text": detected_text,
        "confidence": confidence
    }

# ==================== LOGGING FUNCTION ====================

def log_access_attempt(
    db: Session,
    plate: str,
    name: str,
    status: str,
    reason: str
):
    """
    CRITICAL: Log EVERY access attempt
    Creates immutable audit trail in access_log table
    """
    log = AccessLog(
        timestamp=datetime.utcnow(),
        plate_number=plate,
        name=name,
        status=status,
        reason=reason
    )
    db.add(log)
    db.commit()
    print(f"[LOG] Logged: {status} - {plate} - {reason}")

# ==================== HELPER ENDPOINTS ====================

@app.get("/")
async def root():
    return {
        "service": "Vehicle Authentication System - PHASE 1",
        "status": "operational",
        "endpoints": {
            "check_access": "POST /api/gate/check-access",
            "health": "GET /health",
            "logs": "GET /api/logs"
        }
    }

@app.get("/health")
async def health_check(db: Session = Depends(get_db)):
    """Health check endpoint"""
    try:
        # Test database connection
        db.execute("SELECT 1")
        return {
            "status": "healthy",
            "database": "connected",
            "anpr": "ready" if anpr_processor else "not initialized"
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }

@app.get("/api/logs")
async def get_logs(limit: int = 50, db: Session = Depends(get_db)):
    """Retrieve recent access logs"""
    logs = db.query(AccessLog).order_by(AccessLog.timestamp.desc()).limit(limit).all()
    return {
        "logs": [{
            "timestamp": log.timestamp.isoformat(),
            "plate": log.plate_number,
            "name": log.name,
            "status": log.status,
            "reason": log.reason
        } for log in logs]
    }

@app.get("/api/vehicles")
async def list_vehicles(db: Session = Depends(get_db)):
    """List all registered vehicles"""
    staff = db.query(Staff).all()
    visitors = db.query(Visitor).all()
    
    return {
        "staff": [{
            "id": s.id,
            "name": s.name,
            "plate": s.plate,
            "status": s.status
        } for s in staff],
        "visitors": [{
            "id": v.id,
            "name": v.name,
            "plate": v.plate,
            "expiry": v.expiry.isoformat(),
            "status": v.status
        } for v in visitors]
    }

# ==================== PHASE 3: ADMIN ENDPOINTS ====================

@app.post("/api/admin/vehicle/register")
async def register_vehicle(
    plate_number: str,
    owner_name: str,
    vehicle_type: str,
    expiry_date: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """PHASE 3: Register new vehicle from admin dashboard"""
    print(f"[ADMIN] Registering vehicle: {plate_number}")
    
    # Sanitization (already done by frontend, but defense in depth)
    sanitized_plate = plate_number.upper().replace(" ", "").replace("-", "")
    
    # Check duplicates
    existing_staff = db.query(Staff).filter(Staff.plate == sanitized_plate).first()
    existing_visitor = db.query(Visitor).filter(Visitor.plate == sanitized_plate).first()
    
    if existing_staff or existing_visitor:
        raise HTTPException(
            status_code=409,
            detail=f"Plate {sanitized_plate} is already registered"
        )
    
    # Register based on type
    if vehicle_type.upper() == "STAFF":
        vehicle = Staff(name=owner_name, plate=sanitized_plate, status='OUT')
        db.add(vehicle)
        db.commit()
        db.refresh(vehicle)
        
        return {
            "success": True,
            "message": "Staff vehicle registered",
            "vehicle": {
                "id": vehicle.id,
                "plate": vehicle.plate,
                "owner": vehicle.name,
                "type": "STAFF"
            }
        }
    
    elif vehicle_type.upper() == "VISITOR":
        if not expiry_date:
            raise HTTPException(status_code=400, detail="Visitor requires expiry date")
        
        vehicle = Visitor(
            name=owner_name,
            plate=sanitized_plate,
            expiry=datetime.fromisoformat(expiry_date),
            status='OUT'
        )
        db.add(vehicle)
        db.commit()
        db.refresh(vehicle)
        
        return {
            "success": True,
            "message": "Visitor vehicle registered",
            "vehicle": {
                "id": vehicle.id,
                "plate": vehicle.plate,
                "owner": vehicle.name,
                "type": "VISITOR",
                "expiry": vehicle.expiry.isoformat()
            }
        }
    
    else:
        raise HTTPException(status_code=400, detail="Type must be STAFF or VISITOR")


@app.delete("/api/admin/vehicle/{vehicle_id}")
async def delete_vehicle(vehicle_id: int, vehicle_type: str, db: Session = Depends(get_db)):
    """PHASE 3: Delete/Revoke vehicle access"""
    print(f"[ADMIN] Deleting {vehicle_type} vehicle ID: {vehicle_id}")
    
    if vehicle_type.upper() == "STAFF":
        vehicle = db.query(Staff).filter(Staff.id == vehicle_id).first()
        if not vehicle:
            raise HTTPException(status_code=404, detail="Staff vehicle not found")
        
        plate = vehicle.plate
        db.delete(vehicle)
        db.commit()
        return {"success": True, "message": f"Staff vehicle {plate} deleted"}
    
    elif vehicle_type.upper() == "VISITOR":
        vehicle = db.query(Visitor).filter(Visitor.id == vehicle_id).first()
        if not vehicle:
            raise HTTPException(status_code=404, detail="Visitor vehicle not found")
        
        plate = vehicle.plate
        db.delete(vehicle)
        db.commit()
        return {"success": True, "message": f"Visitor vehicle {plate} deleted"}
    
    else:
        raise HTTPException(status_code=400, detail="Type must be STAFF or VISITOR")


@app.get("/api/admin/vehicles/all")
async def get_all_vehicles(db: Session = Depends(get_db)):
    """PHASE 3: Get all vehicles for admin dashboard"""
    staff = db.query(Staff).all()
    visitors = db.query(Visitor).all()
    
    return {
        "staff": [{
            "id": s.id,
            "plate": s.plate,
            "owner": s.name,
            "status": s.status,
            "type": "STAFF"
        } for s in staff],
        "visitors": [{
            "id": v.id,
            "plate": v.plate,
            "owner": v.name,
            "status": v.status,
            "expiry": v.expiry.isoformat(),
            "type": "VISITOR"
        } for v in visitors]
    }

# ==================== RUN SERVER ====================

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("PHASE 1: Starting FastAPI Server")
    print("="*60 + "\n")
    uvicorn.run(app, host="0.0.0.0", port=5000)
