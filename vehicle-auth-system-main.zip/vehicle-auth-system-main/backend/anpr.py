"""
PHASE 2: Computer Vision Pipeline
Maximum Accuracy OCR with OpenCV Preprocessing + EasyOCR

Implements:
1. Image preprocessing (Grayscale → Blur → Adaptive Threshold)
2. EasyOCR integration
3. Regex validation to filter false readings
"""
import cv2
import numpy as np
import re
from typing import Tuple, Optional
import easyocr

class ANPRVisionPipeline:
    """
    PHASE 2: THE EYE
    Professional-grade ANPR with maximum accuracy
    """
    
    def __init__(self):
        print("[PHASE 2] Initializing Computer Vision Pipeline...")
        
        # Initialize EasyOCR Reader
        # gpu=False for Windows compatibility
        # lang_list=['en'] for English characters only
        print("[OCR] Loading EasyOCR (this may take a minute on first run)...")
        self.reader = easyocr.Reader(['en'], gpu=False)
        print("[OCR] ✓ EasyOCR ready!")
        
        # License Plate Regex Patterns
        # Customize these for your region's plate formats
        self.plate_patterns = [
            r'^[A-Z]{2,4}\s?[0-9]{2,4}$',           # AB 1234 or ABC 123
            r'^[0-9]{1,3}\s?[A-Z]{2,3}\s?[0-9]{1,4}$',  # 1 AB 234
            r'^[A-Z]{1,3}[-\s]?[0-9]{3,4}$',          # AB-1234
        ]
        
        print("[PHASE 2] ✓ Vision pipeline ready!")
    
    def preprocess_image(self, image_bytes: bytes) -> np.ndarray:
        """
        CRITICAL PREPROCESSING PIPELINE
        Converts raw camera pixels into optimal format for OCR
        
        Steps (IN ORDER):
        1. Grayscale - Remove color noise
        2. Gaussian Blur - Smooth graininess
        3. Adaptive Thresholding - Isolate characters from background
        
        Returns: Preprocessed image ready for OCR
        """
        # Decode image bytes to OpenCV format
        nparr = np.frombuffer(image_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if image is None:
            raise ValueError("Invalid image data - cannot decode")
        
        print(f"[PREPROCESS] Original: {image.shape[1]}x{image.shape[0]} pixels")
        
        # STEP 1: GRAYSCALE CONVERSION
        # Removes color channels, reduces data, removes color noise
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        print("[PREPROCESS] ✓ Step 1: Grayscale conversion complete")
        
        # STEP 2: GAUSSIAN BLUR
        # Kernel size (5,5) - smooths image, reduces high-frequency noise
        # Sigma 0 - auto-calculate from kernel size
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        print("[PREPROCESS] ✓ Step 2: Gaussian blur applied")
        
        # STEP 3: ADAPTIVE THRESHOLDING
        # CRUCIAL: Handles different lighting conditions (day/night/shadows)
        # Uses local neighborhood instead of global threshold
        # Block size 11 - size of pixel neighborhood
        # C constant 2 - subtracted from weighted mean
        thresh = cv2.adaptiveThreshold(
            blurred,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            11,
            2
        )
        print("[PREPROCESS] ✓ Step 3: Adaptive thresholding complete")
        
        # Optional: Morphological operations to clean up noise
        kernel = np.ones((3,3), np.uint8)
        cleaned = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        print("[PREPROCESS] ✓ Noise removal applied")
        
        return cleaned
    
    def extract_text_easyocr(self, preprocessed_image: np.ndarray) -> Tuple[str, float]:
        """
        OCR INTEGRATION with EasyOCR
        
        Configuration:
        - Alphanumeric characters only
        - Returns best detection with confidence score
        
        Returns: (text, confidence)
        """
        print("[OCR] Running EasyOCR detection...")
        
        # EasyOCR detection
        # allowlist: only alphanumeric characters (no special chars)
        # batch_size=1: process one image at a time
        results = self.reader.readtext(
            preprocessed_image,
            allowlist='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
            batch_size=1
        )
        
        if not results:
            print("[OCR] No text detected in image")
            return "NO_PLATE", 0.0
        
        # EasyOCR returns list of (bbox, text, confidence)
        # Sort by confidence and take best result
        best_result = max(results, key=lambda x: x[2])
        bbox, text, confidence = best_result
        
        print(f"[OCR] Detected: '{text}' (Confidence: {confidence:.2%})")
        print(f"[OCR] Bounding box: {bbox}")
        
        # Clean and normalize text
        cleaned_text = text.strip().upper()
        
        return cleaned_text, confidence
    
    def validate_plate_format(self, text: str) -> bool:
        """
        VALIDATION FILTER - Regex Check
        
        Purpose: Filter out false readings
        - Prevents detecting street signs as plates
        - Prevents detecting bumper stickers as plates
        - Prevents detecting random text as plates
        
        Returns: True if text matches license plate pattern
        """
        # Remove spaces for pattern matching
        normalized = text.replace(' ', '')
        
        # Check against known plate patterns
        for pattern in self.plate_patterns:
            # Try with and without spaces
            if re.match(pattern, text) or re.match(pattern, normalized):
                print(f"[VALIDATION] ✓ '{text}' matches plate pattern")
                return True
        
        # Fallback validation: reasonable plate characteristics
        # - Contains both letters and numbers
        # - Length between 4-10 characters
        # - Doesn't contain too many numbers or letters
        has_letters = bool(re.search(r'[A-Z]', normalized))
        has_numbers = bool(re.search(r'[0-9]', normalized))
        reasonable_length = 4 <= len(normalized) <= 10
        
        # Count ratio of letters to numbers (should be balanced)
        letter_count = sum(c.isalpha() for c in normalized)
        number_count = sum(c.isdigit() for c in normalized)
        
        # Reject if too many or too few of either
        balanced = letter_count >= 2 and number_count >= 2
        
        is_valid = has_letters and has_numbers and reasonable_length and balanced
        
        if is_valid:
            print(f"[VALIDATION] ✓ '{text}' passes fallback validation")
        else:
            print(f"[VALIDATION] ✗ '{text}' rejected (likely not a plate)")
            print(f"  - Letters: {letter_count}, Numbers: {number_count}, Length: {len(normalized)}")
        
        return is_valid
    
    def sanitize_plate(self, text: str) -> str:
        """
        SANITIZATION for database matching
        
        Removes:
        - All spaces
        - All special characters (-, ., etc)
        - Converts to uppercase
        
        Returns: Clean alphanumeric string
        """
        return ''.join(c for c in text.upper() if c.isalnum())
    
    def process(self, image_bytes: bytes) -> dict:
        """
        COMPLETE PHASE 2 PIPELINE
        
        Flow:
        1. Preprocess image (Grayscale → Blur → Threshold)
        2. Extract text with EasyOCR
        3. Validate with regex
        4. Sanitize for database
        
        Returns: Result dictionary
        """
        try:
            print("\n" + "="*60)
            print("PHASE 2: Computer Vision Pipeline")
            print("="*60)
            
            # STEP 1: Preprocessing
            preprocessed = self.preprocess_image(image_bytes)
            
            # STEP 2: OCR
            detected_text, confidence = self.extract_text_easyocr(preprocessed)
            
            # Check if no plate detected
            if detected_text == "NO_PLATE":
                return {
                    "success": False,
                    "plate": "NO_PLATE",
                    "confidence": 0.0,
                    "error": "No plate detected in image"
                }
            
            # STEP 3: Validation Filter
            is_valid = self.validate_plate_format(detected_text)
            
            if not is_valid:
                print("[PHASE 2] Detected text rejected - not a license plate")
                return {
                    "success": False,
                    "plate": "INVALID",
                    "detected_raw": detected_text,
                    "confidence": confidence,
                    "error": "Detected text does not match plate format"
                }
            
            # STEP 4: Sanitization
            sanitized = self.sanitize_plate(detected_text)
            
            print(f"[PHASE 2] ✓ SUCCESS")
            print(f"  Raw: '{detected_text}'")
            print(f"  Sanitized: '{sanitized}'")
            print(f"  Confidence: {confidence:.2%}")
            
            return {
                "success": True,
                "plate": sanitized,
                "detected_raw": detected_text,
                "confidence": confidence
            }
            
        except Exception as e:
            print(f"[PHASE 2] ERROR: {e}")
            return {
                "success": False,
                "plate": "ERROR",
                "confidence": 0.0,
                "error": str(e)
            }

# For backward compatibility with Phase 1
ANPRProcessor = ANPRVisionPipeline
