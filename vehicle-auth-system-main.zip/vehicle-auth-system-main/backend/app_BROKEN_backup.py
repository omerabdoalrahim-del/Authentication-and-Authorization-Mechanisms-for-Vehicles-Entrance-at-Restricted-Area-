app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Staff(db.Model):
    __tablename__ = 'staff'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    plate_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    status = db.Column(db.String(10), default='OUT')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))

class Visitor(db.Model):
    __tablename__ = 'visitor'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    plate_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    expiry = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(10), default='OUT')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))

class AccessLog(db.Model):
    __tablename__ = 'access_log'
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))
    plate_number = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(100))
    status = db.Column(db.String(20))
    reason = db.Column(db.String(200))

@app.route('/')
def serve_frontend():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/staff', methods=['GET', 'POST'])
def staff_routes():
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        if not name or not plate:
            return jsonify({'error': 'Name and plate number required'}), 400
        try:
            staff = Staff(name=name, plate_number=plate.upper().strip())
            db.session.add(staff)
            db.session.commit()
            return jsonify({'success': True, 'id': staff.id}), 201
        except IntegrityError:
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    staff = Staff.query.all()
    return jsonify([{'id': s.id, 'name': s.name, 'plate': s.plate_number, 'status': s.status} for s in staff])

@app.route('/api/staff/<int:staff_id>', methods=['DELETE'])
def delete_staff(staff_id):
    staff = Staff.query.get_or_404(staff_id)
    try:
        db.session.delete(staff)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@app.route('/api/visitors', methods=['GET', 'POST'])
def visitor_routes():
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        expiry = data.get('expiry')
        if not all([name, plate, expiry]):
            return jsonify({'error': 'All fields required'}), 400
        try:
            visitor = Visitor(
                name=name,
                plate_number=plate.upper().strip(),
                expiry=datetime.fromisoformat(expiry.replace('Z', '+00:00'))
            )
            db.session.add(visitor)
            db.session.commit()
            return jsonify({'success': True, 'id': visitor.id}), 201
        except IntegrityError:
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    visitors = Visitor.query.all()
    return jsonify([{
        'id': v.id,
        'name': v.name,
        'plate': v.plate_number,
        'expiry': v.expiry.isoformat(),
        'status': v.status
    } for v in visitors])

@app.route('/api/visitors/<int:visitor_id>', methods=['DELETE'])
def delete_visitor(visitor_id):
    visitor = Visitor.query.get_or_404(visitor_id)
    try:
        db.session.delete(visitor)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@app.route('/api/process-vehicle', methods=['POST'])
def process_vehicle():
    data = request.get_json()
    plate = data.get('plate_number', '').upper().strip()
    
    if not plate:
        return jsonify({'error': 'Plate number required'}), 400

    print(f"\n{'='*60}")
    print(f"[AUTH] Processing plate: '{plate}' (Smart Auto-Detection)")
    
    # DEBUG: Show what's in the database
    all_staff = Staff.query.all()
    all_visitors = Visitor.query.all()
    print(f"[DEBUG] Staff plates in DB: {[s.plate_number for s in all_staff]}")
    print(f"[DEBUG] Visitor plates in DB: {[v.plate_number for v in all_visitors]}")
    print(f"[DEBUG] Looking for: '{plate}'")
    print(f"{'='*60}")
    
    # Optimized: Try staff first with indexed query
    vehicle = Staff.query.filter_by(plate_number=plate).first()
    is_visitor = False
    vehicle_type = "Staff"
    
    # If not staff, check visitors with indexed query
    if not vehicle:
        vehicle = Visitor.query.filter_by(plate_number=plate).first()
        is_visitor = True
        vehicle_type = "Visitor"

    if not vehicle:
        print(f"❌ NOT FOUND: '{plate}' is not registered!")
        log_access('DENIED', plate, 'Unknown', 'Unauthorized Vehicle - Not Registered')
        return jsonify({
            'status': 'DENIED',
            'message': 'Unauthorized Vehicle - Not Registered',
            'name': 'Unknown',
            'plate_number': plate
        })

    print(f"✅ FOUND: '{plate}' is registered as {vehicle_type} - {vehicle.name}")
    
    timestamp = datetime.now(MALAYSIA_TZ)
    
    # Fix timezone comparison for visitor expiry
    if is_visitor and vehicle.expiry:
        # Convert visitor expiry to timezone-aware if it's naive
        if vehicle.expiry.tzinfo is None:
            visitor_expiry = vehicle.expiry.replace(tzinfo=MALAYSIA_TZ)
        else:
            visitor_expiry = vehicle.expiry
        
        if visitor_expiry < timestamp:
            log_access('DENIED', plate, vehicle.name, 'Visitor access expired')
            return jsonify({
                'status': 'DENIED',
                'message': 'Visitor access expired',
                'name': vehicle.name,
                'plate_number': plate
            })

    # 🔥 SMART AUTO-DETECTION: Automatically determine direction based on current status
    if vehicle.status == 'OUT':
        # Vehicle is outside → Let them IN
        vehicle.status = 'IN'
        status = 'ENTRY GRANTED'
        reason = f'{vehicle_type} entering restricted area'
        print(f"✅ Auto-detected: Vehicle OUT → IN (Entry)")
    else:
        # Vehicle is inside → Let them OUT
        vehicle.status = 'OUT'
        status = 'EXIT RECORDED'
        reason = f'{vehicle_type} leaving restricted area'
        print(f"✅ Auto-detected: Vehicle IN → OUT (Exit)")
    
    db.session.commit()
    log_access(status, plate, vehicle.name, reason)
    
    return jsonify({
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Staff(db.Model):
    __tablename__ = 'staff'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    plate_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    status = db.Column(db.String(10), default='OUT')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))

class Visitor(db.Model):
    __tablename__ = 'visitor'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    plate_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    expiry = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(10), default='OUT')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))

class AccessLog(db.Model):
    __tablename__ = 'access_log'
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))
    plate_number = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(100))
    status = db.Column(db.String(20))
    reason = db.Column(db.String(200))

@app.route('/')
def serve_frontend():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/staff', methods=['GET', 'POST'])
def staff_routes():
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        if not name or not plate:
            return jsonify({'error': 'Name and plate number required'}), 400
        try:
            staff = Staff(name=name, plate_number=plate.upper().strip())
            db.session.add(staff)
            db.session.commit()
            return jsonify({'success': True, 'id': staff.id}), 201
        except IntegrityError:
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    staff = Staff.query.all()
    return jsonify([{'id': s.id, 'name': s.name, 'plate': s.plate_number, 'status': s.status} for s in staff])

@app.route('/api/staff/<int:staff_id>', methods=['DELETE'])
def delete_staff(staff_id):
    staff = Staff.query.get_or_404(staff_id)
    try:
        db.session.delete(staff)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@app.route('/api/visitors', methods=['GET', 'POST'])
def visitor_routes():
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        expiry = data.get('expiry')
        if not all([name, plate, expiry]):
            return jsonify({'error': 'All fields required'}), 400
        try:
            visitor = Visitor(
                name=name,
                plate_number=plate.upper().strip(),
                expiry=datetime.fromisoformat(expiry.replace('Z', '+00:00'))
            )
            db.session.add(visitor)
            db.session.commit()
            return jsonify({'success': True, 'id': visitor.id}), 201
        except IntegrityError:
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    visitors = Visitor.query.all()
    return jsonify([{
        'id': v.id,
        'name': v.name,
        'plate': v.plate_number,
        'expiry': v.expiry.isoformat(),
        'status': v.status
    } for v in visitors])

@app.route('/api/visitors/<int:visitor_id>', methods=['DELETE'])
def delete_visitor(visitor_id):
    visitor = Visitor.query.get_or_404(visitor_id)
    try:
        db.session.delete(visitor)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@app.route('/api/process-vehicle', methods=['POST'])
def process_vehicle():
    data = request.get_json()
    plate = data.get('plate_number', '').upper().strip()
    
    if not plate:
        return jsonify({'error': 'Plate number required'}), 400

    print(f"\n{'='*60}")
    print(f"[AUTH] Processing plate: '{plate}' (Smart Auto-Detection)")
    
    # DEBUG: Show what's in the database
    all_staff = Staff.query.all()
    all_visitors = Visitor.query.all()
    print(f"[DEBUG] Staff plates in DB: {[s.plate_number for s in all_staff]}")
    print(f"[DEBUG] Visitor plates in DB: {[v.plate_number for v in all_visitors]}")
    print(f"[DEBUG] Looking for: '{plate}'")
    print(f"{'='*60}")
    
    # Optimized: Try staff first with indexed query
    vehicle = Staff.query.filter_by(plate_number=plate).first()
    is_visitor = False
    vehicle_type = "Staff"
    
    # If not staff, check visitors with indexed query
    if not vehicle:
        vehicle = Visitor.query.filter_by(plate_number=plate).first()
        is_visitor = True
        vehicle_type = "Visitor"

    if not vehicle:
        print(f"❌ NOT FOUND: '{plate}' is not registered!")
        log_access('DENIED', plate, 'Unknown', 'Unauthorized Vehicle - Not Registered')
        return jsonify({
            'status': 'DENIED',
            'message': 'Unauthorized Vehicle - Not Registered',
            'name': 'Unknown',
            'plate_number': plate
        })

    print(f"✅ FOUND: '{plate}' is registered as {vehicle_type} - {vehicle.name}")
    
    timestamp = datetime.now(MALAYSIA_TZ)
    
    # Fix timezone comparison for visitor expiry
    if is_visitor and vehicle.expiry:
        # Convert visitor expiry to timezone-aware if it's naive
        if vehicle.expiry.tzinfo is None:
            visitor_expiry = vehicle.expiry.replace(tzinfo=MALAYSIA_TZ)
        else:
            visitor_expiry = vehicle.expiry
        
        if visitor_expiry < timestamp:
            log_access('DENIED', plate, vehicle.name, 'Visitor access expired')
            return jsonify({
                'status': 'DENIED',
                'message': 'Visitor access expired',
                'name': vehicle.name,
                'plate_number': plate
            })

    # 🔥 SMART AUTO-DETECTION: Automatically determine direction based on current status
    if vehicle.status == 'OUT':
        # Vehicle is outside → Let them IN
        vehicle.status = 'IN'
        status = 'ENTRY GRANTED'
        reason = f'{vehicle_type} entering restricted area'
        print(f"✅ Auto-detected: Vehicle OUT → IN (Entry)")
    else:
        # Vehicle is inside → Let them OUT
        vehicle.status = 'OUT'
        status = 'EXIT RECORDED'
        reason = f'{vehicle_type} leaving restricted area'
        print(f"✅ Auto-detected: Vehicle IN → OUT (Exit)")
    
    db.session.commit()
    log_access(status, plate, vehicle.name, reason)
    
    return jsonify({
        'status': status,
        'message': reason,
        'name': vehicle.name,
        'plate_number': plate
    })

@app.route('/api/access-logs', methods=['GET'])
def get_access_logs():
    logs = AccessLog.query.order_by(AccessLog.timestamp.desc()).limit(50).all()
    return jsonify([{
        'timestamp': log.timestamp.isoformat(),
        'plate': log.plate_number,
        'name': log.name,
        'status': log.status,
        'reason': log.reason
    } for log in logs])

@app.route('/api/ocr/scan', methods=['POST'])
def ocr_scan():
    """OCR.space FREE API - 25,000 scans/month!"""
    print("=" * 60)
    print("[OCR.space] Scan request received")
    
    data = request.get_json()
    if not data or not data.get('image'):
        print("[OCR.space] ERROR: No image")
        return jsonify({'error': 'No image', 'message': 'Camera offline', 'text': 'NOPLATE'}), 400
    
    try:
        image_data = data['image']
        
        # Call OCR.space FREE API
        result = scan_with_ocr_space(image_data, OCR_SPACE_API_KEY)
        
        return jsonify(result)
    
    except Exception as e:
        print(f"[OCR.space] ❌ EXCEPTION: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e), 'message': 'OCR error', 'text': 'NOPLATE'}), 500

def log_access(status, plate, name, reason):
    log = AccessLog(
        timestamp=datetime.now(MALAYSIA_TZ),
        plate_number=plate,
        name=name,
        status=status,
        reason=reason
    )
    db.session.add(log)
    db.session.commit()

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)