@echo off
REM Production Startup Script for Windows
REM PHASE 5: Runs backend with multiple workers

echo ==========================================
echo SecureGate Production Server (Windows)
echo ==========================================

REM Create logs directory
if not exist logs mkdir logs

REM Number of workers (recommended: 4 for most systems)
SET WORKERS=4

echo Starting with %WORKERS% workers...

REM Run with Uvicorn only (Gunicorn is Unix-only)
REM For Windows production, use multiple uvicorn instances behind a load balancer
uvicorn phase1_app:app --host 0.0.0.0 --port 5000 --workers %WORKERS% --log-level info

echo Server stopped.
pause
