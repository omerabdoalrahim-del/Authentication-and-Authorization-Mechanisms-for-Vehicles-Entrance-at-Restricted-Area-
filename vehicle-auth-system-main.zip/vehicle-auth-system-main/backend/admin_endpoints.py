"""
PHASE 3: Additional Backend Endpoints for Admin Dashboard
Add vehicle CRUD operations
"""

# Add these endpoints to phase1_app.py

@app.post("/api/admin/vehicle/register")
async def register_vehicle(
    plate_number: str,
    owner_name: str,
    vehicle_type: str,
    expiry_date: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Register a new vehicle (Staff or Visitor)
    Frontend ensures plate is uppercase and stripped
    """
    print(f"[ADMIN] Registering vehicle: {plate_number}")
    
    # Double-check sanitization (defense in depth)
    sanitized_plate = plate_number.upper().replace(" ", "").replace("-", "")
    
    # Check if already exists
    existing_staff = db.query(Staff).filter(Staff.plate == sanitized_plate).first()
    existing_visitor = db.query(Visitor).filter(Visitor.plate == sanitized_plate).first()
    
    if existing_staff or existing_visitor:
        raise HTTPException(
            status_code=409,
            detail=f"Plate {sanitized_plate} is already registered"
        )
    
    # Register based on type
    if vehicle_type.upper() == "STAFF":
        vehicle = Staff(
            name=owner_name,
            plate=sanitized_plate,
            status='OUT'
        )
        db.add(vehicle)
        db.commit()
        db.refresh(vehicle)
        
        return {
            "success": True,
            "message": "Staff vehicle registered",
            "vehicle": {
                "id": vehicle.id,
                "plate": vehicle.plate,
                "owner": vehicle.name,
                "type": "STAFF"
            }
        }
    
    elif vehicle_type.upper() == "VISITOR":
        if not expiry_date:
            raise HTTPException(
                status_code=400,
                detail="Visitor vehicles require expiry date"
            )
        
        vehicle = Visitor(
            name=owner_name,
            plate=sanitized_plate,
            expiry=datetime.fromisoformat(expiry_date),
            status='OUT'
        )
        db.add(vehicle)
        db.commit()
        db.refresh(vehicle)
        
        return {
            "success": True,
            "message": "Visitor vehicle registered",
            "vehicle": {
                "id": vehicle.id,
                "plate": vehicle.plate,
                "owner": vehicle.name,
                "type": "VISITOR",
                "expiry": vehicle.expiry.isoformat()
            }
        }
    
    else:
        raise HTTPException(
            status_code=400,
            detail="Vehicle type must be STAFF or VISITOR"
        )


@app.delete("/api/admin/vehicle/{vehicle_id}")
async def delete_vehicle(
    vehicle_id: int,
    vehicle_type: str,
    db: Session = Depends(get_db)
):
    """
    Delete/Revoke a vehicle
    """
    print(f"[ADMIN] Deleting {vehicle_type} vehicle ID: {vehicle_id}")
    
    if vehicle_type.upper() == "STAFF":
        vehicle = db.query(Staff).filter(Staff.id == vehicle_id).first()
        if not vehicle:
            raise HTTPException(status_code=404, detail="Staff vehicle not found")
        
        plate = vehicle.plate
        db.delete(vehicle)
        db.commit()
        
        return {
            "success": True,
            "message": f"Staff vehicle {plate} deleted"
        }
    
    elif vehicle_type.upper() == "VISITOR":
        vehicle = db.query(Visitor).filter(Visitor.id == vehicle_id).first()
        if not vehicle:
            raise HTTPException(status_code=404, detail="Visitor vehicle not found")
        
        plate = vehicle.plate
        db.delete(vehicle)
        db.commit()
        
        return {
            "success": True,
            "message": f"Visitor vehicle {plate} deleted"
        }
    
    else:
        raise HTTPException(
            status_code=400,
            detail="Vehicle type must be STAFF or VISITOR"
        )


@app.get("/api/admin/vehicles/all")
async def get_all_vehicles(db: Session = Depends(get_db)):
    """
    Get all vehicles (Staff + Visitors) for admin dashboard
    """
    staff = db.query(Staff).all()
    visitors = db.query(Visitor).all()
    
    return {
        "staff": [{
            "id": s.id,
            "plate": s.plate,
            "owner": s.name,
            "status": s.status,
            "type": "STAFF"
        } for s in staff],
        "visitors": [{
            "id": v.id,
            "plate": v.plate,
            "owner": v.name,
            "status": v.status,
            "expiry": v.expiry.isoformat(),
            "type": "VISITOR"
        } for v in visitors]
    }
