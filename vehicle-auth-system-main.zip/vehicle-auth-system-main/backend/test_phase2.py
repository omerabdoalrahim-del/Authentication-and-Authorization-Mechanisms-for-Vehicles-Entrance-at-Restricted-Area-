"""
PHASE 2 Test Script
Quick test of the Computer Vision pipeline
"""
from anpr import ANPRVisionPipeline
import cv2
import sys

def test_phase2():
    print("\n" + "="*60)
    print("PHASE 2: Computer Vision Pipeline Test")
    print("="*60 + "\n")
    
    # Initialize
    print("[TEST] Initializing ANPR Vision Pipeline...")
    try:
        pipeline = ANPRVisionPipeline()
    except Exception as e:
        print(f"\n❌ FAILED TO INITIALIZE")
        print(f"Error: {e}")
        print("\nℹ️  Make sure EasyOCR is installed:")
        print("   pip install torch torchvision easyocr opencv-python")
        return False
    
    print("\n[TEST] ✓ Pipeline initialized successfully!\n")
    
    # Test with sample image
    print("[TEST] Testing with sample image...")
    print("Please provide a license plate image path, or press Enter to skip.")
    image_path = input("Image path: ").strip()
    
    if not image_path:
        print("\n[TEST] No image provided. Testing with blank image...")
        # Create a simple test image
        import numpy as np
        test_image = np.zeros((480, 640, 3), dtype=np.uint8)
        cv2.putText(test_image, "ABC1234", (200, 240), 
                   cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)
        _, buffer = cv2.imencode('.jpg', test_image)
        image_bytes = buffer.tobytes()
    else:
        try:
            image = cv2.imread(image_path)
            if image is None:
                print(f"❌ Could not read image: {image_path}")
                return False
            _, buffer = cv2.imencode('.jpg', image)
            image_bytes = buffer.tobytes()
        except Exception as e:
            print(f"❌ Error loading image: {e}")
            return False
    
    # Process
    print("\n[TEST] Processing image...")
    result = pipeline.process(image_bytes)
    
    # Display results
    print("\n" + "="*60)
    print("RESULTS")
    print("="*60)
    print(f"Success: {result.get('success')}")
    print(f"Plate: {result.get('plate')}")
    print(f"Raw Detection: {result.get('detected_raw')}")
    print(f"Confidence: {result.get('confidence', 0):.2%}")
    if 'error' in result:
        print(f"Error: {result.get('error')}")
    print("="*60)
    
    return result.get('success', False)

if __name__ == "__main__":
    success = test_phase2()
    sys.exit(0 if success else 1)
