import csv, sys, pathlib

p = sys.argv[1] if len(sys.argv) > 1 else r'plate-dataset\label.csv'
p = pathlib.Path(p)
if not p.exists():
    print('labels file not found:', p)
    raise SystemExit(1)

with p.open(newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    headers = next(reader, None)
    print('Headers:', headers)
    print('First 20 rows:')
    for i, row in enumerate(reader):
        print(i+1, row)
        if i >= 18:
            break

# Basic format detection
if headers:
    has_bbox = any(h.lower() in ('x_center','y_center','width','height','xmin','ymin','xmax','ymax') for h in headers)
    print('Detected bbox columns?' , has_bbox)