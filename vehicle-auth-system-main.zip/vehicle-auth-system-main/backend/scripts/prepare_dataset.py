"""
Dataset Preparation Script for License Plate Recognition

This script prepares a dataset for training a license plate recognition model by:
1. Reading labeled images from a source directory
2. Normalizing license plate text
3. Splitting data into training and validation sets
4. Organizing files with proper structure for model training

Author: Vehicle Authentication System Team
Created: 2025
"""

import csv
import os
import shutil
import random
import argparse
from pathlib import Path


def normalize_plate(s):
    """
    Normalize license plate text to a standard format.
    
    This function standardizes license plate strings by:
    - Converting to uppercase
    - Removing all non-alphanumeric characters except hyphens
    - Ensuring consistent format for database matching
    
    Args:
        s (str): Raw license plate string from CSV or detection
        
    Returns:
        str: Normalized plate string (uppercase, alphanumeric + hyphens only)
        
    Examples:
        >>> normalize_plate("abc 123")
        "ABC123"
        >>> normalize_plate("stf-102")
        "STF-102"
    """
    return ''.join(ch for ch in (s or '').upper() if ch.isalnum() or ch == '-')

def main(src_dir, out_dir, val_pct=0.15):
    """
    Main dataset preparation workflow.
    
    This function orchestrates the entire dataset preparation process:
    1. Locates source images and label CSV file
    2. Parses and normalizes all plate labels
    3. Randomly splits data into training/validation sets
    4. Copies images and creates label files in proper format
    5. Generates manifest CSV files for both splits
    
    Args:
        src_dir (str): Path to source directory containing:
                       - images/ subdirectory with plate images
                       - label.csv or labels.csv with plate annotations
        out_dir (str): Path to output directory where processed dataset will be created
        val_pct (float, optional): Percentage of data for validation set (default: 0.15 = 15%)
        
    Returns:
        None
        
    Directory Structure Created:
        out_dir/
        ├── images/
        │   ├── train_image001.jpg
        │   ├── val_image002.jpg
        │   └── ...
        ├── labels/
        │   ├── train_image001.jpg.txt
        │   ├── val_image002.jpg.txt
        │   └── ...
        ├── train_manifest.csv
        └── val_manifest.csv
    """
    # Initialize paths
    src = Path(src_dir)
    out = Path(out_dir)
    images_src = src / 'images'
    
    # Locate label CSV file (try both common naming conventions)
    labels_csv = src / 'label.csv'
    if not labels_csv.exists():
        labels_csv = src / 'labels.csv'
    if not labels_csv.exists():
        print('label.csv not found in', src)
        return

    # Create output directory structure
    out_images = out / 'images'
    out_labels = out / 'labels'
    out_images.mkdir(parents=True, exist_ok=True)
    out_labels.mkdir(parents=True, exist_ok=True)

    # Parse CSV and extract filename-plate pairs
    # This handles various CSV column naming conventions
    rows = []
    with labels_csv.open(newline='', encoding='utf-8') as fh:
        reader = csv.DictReader(fh)
        for r in reader:
            # Try multiple column names for flexibility
            fname = (r.get('filename') or r.get('file') or r.get('image') or r.get('name'))
            plate = r.get('plate') or r.get('label') or r.get('text') or ''
            if not fname:
                continue
            plate = normalize_plate(plate)  # Standardize format
            rows.append({'filename': fname, 'plate': plate, 'raw': r})

    # Randomly split into train/validation sets
    random.shuffle(rows)  # Randomize to avoid bias
    nval = int(len(rows) * val_pct)
    val = rows[:nval]      # First N% for validation
    train = rows[nval:]    # Remaining for training

    def copy_rows(list_rows, split):
        """
        Process and copy images for a specific split (train or val).
        
        Args:
            list_rows (list): List of dictionaries with filename and plate data
            split (str): Split name ('train' or 'val') for prefixing files
        """
        manifest = []
        for r in list_rows:
            # Search for image file in multiple common locations
            # (handles different dataset organization structures)
            candidates = [
                images_src / r['filename'],  # Standard: dataset/images/file.jpg
                src / r['filename'],          # Flat: dataset/file.jpg
                Path(r['filename'])           # Absolute path
            ]
            src_path = next((c for c in candidates if c.exists()), None)
            
            if not src_path:
                print('MISSING:', r['filename'])
                continue
            
            # Copy image with split prefix (e.g., train_image001.jpg)
            dst_name = f'{split}_{src_path.name}'
            dst = out_images / dst_name
            shutil.copy2(src_path, dst)  # Preserves metadata
            
            # Create corresponding label file (for OCR training)
            # Format: single line containing the normalized plate text
            with open(out_labels / f'{dst_name}.txt', 'w', encoding='utf-8') as L:
                L.write(r['plate'])
            manifest.append((dst_name, r['plate']))
        
        # Generate manifest CSV (index of all processed files)
        with open(out / f'{split}_manifest.csv', 'w', newline='', encoding='utf-8') as mf:
            import csv as _csv
            w = _csv.writer(mf)
            w.writerow(['filename','plate'])  # Header
            w.writerows(manifest)             # All filename-plate pairs
        print(f'Wrote {len(manifest)} items for {split}')

    # Process both training and validation splits
    copy_rows(train, 'train')
    copy_rows(val, 'val')
    
    # Display summary statistics
    print('Prepared dataset at', out)
    print('Processed images count:', len(list(out_images.glob('*'))))
    
    # Preview first 10 lines of training manifest for verification
    with open(out / 'train_manifest.csv', 'r', encoding='utf-8') as f:
        print(''.join([next(f) for _ in range(10)]))


# ============================================================================
# COMMAND-LINE INTERFACE
# ============================================================================

if __name__ == '__main__':
    """
    Command-line entry point for dataset preparation.
    
    Usage:
        python prepare_dataset.py <src_dir> <out_dir> [--val 0.15]
    
    Example:
        python prepare_dataset.py ./raw_dataset ./processed_dataset --val 0.2
    """
    # Configure argument parser
    p = argparse.ArgumentParser(
        description='Prepare license plate dataset for OCR model training',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s ./raw_plates ./dataset_ready
  %(prog)s C:\\data\\plates C:\\training\\plates --val 0.2
        """
    )
    
    # Required arguments
    p.add_argument('src_dir', 
                   help='Source dataset folder (must contain images/ subdirectory and label.csv)')
    p.add_argument('out_dir', 
                   help='Output folder where processed dataset will be created')
    
    # Optional arguments
    p.add_argument('--val', 
                   type=float, 
                   default=0.15,
                   help='Validation set percentage (default: 0.15 = 15%%)')
    
    args = p.parse_args()
    
    # Execute main processing workflow
    main(args.src_dir, args.out_dir, args.val)

# ============================================================================
# POWERSHELL USAGE EXAMPLES (for reference, not executed)
# ============================================================================
# cd "C:\Users\WIS\OneDrive\Desktop\vehicle-auth-system"
# Get-ChildItem -Force
# Get-ChildItem .\plate-dataset -Name
# Get-ChildItem .\plate-dataset\images -File | Select-Object -First 10
# Get-Content .\plate-dataset\label.csv -TotalCount 10