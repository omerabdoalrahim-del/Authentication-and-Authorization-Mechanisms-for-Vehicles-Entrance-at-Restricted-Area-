from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Enum as SQLEnum, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from datetime import datetime
import enum

Base = declarative_base()

class VehicleType(str, enum.Enum):
    STAFF = "STAFF"
    VISITOR = "VISITOR"

class UserRole(str, enum.Enum):
    ADMIN = "ADMIN"
    GUARD = "GUARD"

class AccessStatus(str, enum.Enum):
    GRANTED = "GRANTED"
    DENIED = "DENIED"

# Users Table - System Access Control
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(SQLEnum(UserRole), nullable=False, default=UserRole.GUARD)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)

# Vehicles Table - SOURCE OF TRUTH for Authentication
class Vehicle(Base):
    __tablename__ = "vehicles"
    
    id = Column(Integer, primary_key=True, index=True)
    plate_number = Column(String(20), unique=True, nullable=False, index=True)  # B-Tree indexed
    owner_name = Column(String(100), nullable=False)
    vehicle_type = Column(SQLEnum(VehicleType), nullable=False)
    registration_date = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True, nullable=False)
    expiry_date = Column(DateTime(timezone=True), nullable=True)  # For visitors
    created_by = Column(Integer, nullable=True)
    
    __table_args__ = (
        Index('idx_plate_active', 'plate_number', 'is_active'),  # Composite index for faster lookups
    )

# AccessLogs Table - IMMUTABLE Audit Trail
class AccessLog(Base):
    __tablename__ = "access_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    plate_number_detected = Column(String(50), nullable=False, index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    status = Column(SQLEnum(AccessStatus), nullable=False)
    confidence_score = Column(Float, nullable=True)
    rejection_reason = Column(String(200), nullable=True)
    vehicle_type = Column(String(20), nullable=True)
    owner_name = Column(String(100), nullable=True)
    gate_id = Column(String(50), default="GATE_1")
    
    __table_args__ = (
        Index('idx_timestamp', 'timestamp'),
        Index('idx_status', 'status'),
    )
