"""
Vehicle Authentication System - Flask Backend Server

This module implements the core backend API for an Automatic Number Plate Recognition (ANPR)
vehicle authentication system. It provides RESTful endpoints for:

1. **Vehicle Management**
   - Staff plate registration (permanent access)
   - Visitor plate registration (time-limited access)
   - Vehicle record retrieval and deletion

2. **Access Control**
   - Real-time plate authentication via OCR
   - Smart entry/exit detection based on vehicle status
   - Access denial for unauthorized or expired credentials

3. **Audit Logging**
   - Immutable access logs for all entry/exit events
   - Queryable log history for security monitoring

**Technology Stack:**
- Flask (Web framework)
- SQLAlchemy (ORM for database operations)
- OCR.space API (License plate text recognition)
- PostgreSQL/SQLite (Database)

**Database Tables:**
- `staff` - Permanent vehicle registrations
- `visitor` - Temporary vehicle registrations with expiry dates
- `access_log` - Audit trail of all access attempts

Author: Vehicle Authentication System Team
Created: 2025
License: MIT
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError
from datetime import datetime, timezone, timedelta
import os
from dotenv import load_dotenv
import base64
import requests

# Load environment variables from .env file
load_dotenv()

# ============================================================================
# CONFIGURATION
# ============================================================================

# Malaysia timezone (GMT+8) - All timestamps use this timezone
MALAYSIA_TZ = timezone(timedelta(hours=8))

# OpenRouter API Configuration (for AI-powered features, if enabled)
OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY')
OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"

# ============================================================================
# FLASK APPLICATION INITIALIZATION
# ============================================================================

# Initialize Flask app with frontend served from ../frontend directory
app = Flask(__name__, static_folder='../frontend', static_url_path='')

# Enable Cross-Origin Resource Sharing (CORS) for frontend access
CORS(app)

# Database configuration (supports both PostgreSQL and SQLite)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///vehicle_auth.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Disable modification tracking for performance
db = SQLAlchemy(app)

# ============================================================================
# HTTP RESPONSE MIDDLEWARE
# ============================================================================

# Disable caching for development
@app.after_request
def add_header(response):
    """
    Disable HTTP caching for all responses during development.
    
    This ensures that the frontend always receives fresh data and
    prevents browsers from serving stale cached responses.
    
    Args:
        response: Flask response object
        
    Returns:
        Response object with no-cache headers added
    """
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '-1'
    return response

# ============================================================================
# DATABASE MODELS
# ============================================================================

class Staff(db.Model):
    """
    Staff Vehicle Registration Model (Permanent Access)
    
    Stores vehicle information for staff members who have permanent
    access to the facility. Staff vehicles do not have expiry dates.
    
    Attributes:
        id (int): Primary key
        name (str): Staff member's full name
        plate_number (str): License plate number (normalized, indexed for fast lookups)
        status (str): Current location status ('IN' or 'OUT')
        created_at (datetime): Registration timestamp (Malaysia timezone)
    """
    __tablename__ = 'staff'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    plate_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    status = db.Column(db.String(10), default='OUT')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))

class Visitor(db.Model):
    """
    Visitor Vehicle Registration Model (Time-Limited Access)
    
    Stores vehicle information for temporary visitors who have time-limited
    access to the facility. Access is automatically denied after expiry.
    
    Attributes:
        id (int): Primary key
        name (str): Visitor's full name
        plate_number (str): License plate number (normalized, indexed for fast lookups)
        expiry (datetime): Access expiration timestamp (Malaysia timezone)
        status (str): Current location status ('IN' or 'OUT')
        created_at (datetime): Registration timestamp (Malaysia timezone)
    """
    __tablename__ = 'visitor'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    plate_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    expiry = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(10), default='OUT')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))

class AccessLog(db.Model):
    """
    Access Log Model (Immutable Audit Trail)
    
    Stores an immutable record of all vehicle access attempts for security
    auditing and compliance. Records are never deleted, only queried.
    
    Attributes:
        id (int): Primary key
        timestamp (datetime): When the access attempt occurred (Malaysia timezone)
        plate_number (str): License plate detected/processed
        name (str): Vehicle owner name (if registered)
        status (str): Access result ('ENTRY GRANTED', 'EXIT RECORDED', 'DENIED')
        reason (str): Detailed reason for access decision
    """
    __tablename__ = 'access_log'
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(MALAYSIA_TZ))
    plate_number = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(100))
    status = db.Column(db.String(20))
    reason = db.Column(db.String(200))

# ============================================================================
# API ENDPOINTS - FRONTEND SERVING
# ============================================================================

@app.route('/')
def serve_frontend():
    """
    Serve the main frontend HTML page.
    
    Returns:
        HTML file: The admin/gate dashboard interface
    """
    return send_from_directory(app.static_folder, 'index.html')

# ============================================================================
# API ENDPOINTS - STAFF MANAGEMENT
# ============================================================================

@app.route('/api/staff', methods=['GET', 'POST'])
def staff_routes():
    """
    Staff Management Endpoint (List and Create)
    
    **GET** - Retrieve all staff vehicle registrations
    Returns:
        JSON array of staff objects with id, name, plate, status
        
    **POST** - Register a new staff vehicle
    Request Body:
        {
            "name": str (required),
            "plate_number": str (required)
        }
    Returns:
        201 Created - {"success": true, "id": int}
        400 Bad Request - {"error": str}  (missing fields)
        409 Conflict - {"error": str}  (duplicate plate)
    """
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        
        # Validate required fields
        if not name or not plate:
            return jsonify({'error': 'Name and plate number required'}), 400
        
        try:
            # Create new staff record with normalized plate number
            staff = Staff(name=name, plate_number=plate.upper().strip())
            db.session.add(staff)
            db.session.commit()
            return jsonify({'success': True, 'id': staff.id}), 201
        except IntegrityError:
            # Duplicate plate number
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            # Other database errors
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    # GET: Return all staff members with their details
    staff = Staff.query.all()
    return jsonify([{'id': s.id, 'name': s.name, 'plate': s.plate_number, 'status': s.status} for s in staff])

@app.route('/api/staff/<int:staff_id>', methods=['DELETE'])
def delete_staff(staff_id):
    """
    Delete a staff vehicle registration.
    
    Args:
        staff_id (int): ID of the staff record to delete
        
    Returns:
        200 OK - {"success": true}
        400 Bad Request - {"error": str}  (database error)
        404 Not Found - (invalid staff_id)
    """
    staff = Staff.query.get_or_404(staff_id)
    try:
        db.session.delete(staff)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

# ============================================================================
# API ENDPOINTS - VISITOR MANAGEMENT
# ============================================================================

@app.route('/api/visitors', methods=['GET', 'POST'])
def visitor_routes():
    """
    Visitor Management Endpoint (List and Create)
    
    **GET** - Retrieve all visitor vehicle registrations
    Returns:
        JSON array of visitor objects with id, name, plate, expiry, status
        
    **POST** - Register a new visitor vehicle with time-limited access
    Request Body:
        {
            "name": str (required),
            "plate_number": str (required),
            "expiry": str (required, ISO 8601 format datetime)
        }
    Returns:
        201 Created - {"success": true, "id": int}
        400 Bad Request - {"error": str}  (missing fields or invalid date)
        409 Conflict - {"error": str}  (duplicate plate)
    """
    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        plate = data.get('plate_number')
        expiry = data.get('expiry')
        
        # Validate all required fields
        if not all([name, plate, expiry]):
            return jsonify({'error': 'All fields required'}), 400
        
        try:
            # Create new visitor record with expiry date
            visitor = Visitor(
                name=name,
                plate_number=plate.upper().strip(),
                expiry=datetime.fromisoformat(expiry.replace('Z', '+00:00'))
            )
            db.session.add(visitor)
            db.session.commit()
            return jsonify({'success': True, 'id': visitor.id}), 201
        except IntegrityError:
            # Duplicate plate number
            db.session.rollback()
            return jsonify({'error': f"Plate '{plate}' already registered"}), 409
        except Exception as e:
            # Invalid date format or other database errors
            db.session.rollback()
            return jsonify({'error': str(e)}), 400
    
    # GET: Return all visitors with their details including expiry
    visitors = Visitor.query.all()
    return jsonify([{
        'id': v.id,
        'name': v.name,
        'plate': v.plate_number,
        'expiry': v.expiry.isoformat(),
        'status': v.status
    } for v in visitors])

@app.route('/api/visitors/<int:visitor_id>', methods=['DELETE'])
def delete_visitor(visitor_id):
    """
    Delete a visitor vehicle registration.
    
    Args:
        visitor_id (int): ID of the visitor record to delete
        
    Returns:
        200 OK - {"success": true}
        400 Bad Request - {"error": str}  (database error)
        404 Not Found - (invalid visitor_id)
    """
    visitor = Visitor.query.get_or_404(visitor_id)
    try:
        db.session.delete(visitor)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

# ============================================================================
# API ENDPOINTS - ACCESS CONTROL (CORE AUTHENTICATION)
# ============================================================================

@app.route('/api/process-vehicle', methods=['POST'])
def process_vehicle():
    """
    Core Vehicle Access Control Endpoint (SMART AUTO-DETECTION)
    
    This is the heart of the ANPR system. It processes a license plate number
    and makes an access control decision using the following logic:
    
    **Authentication Flow:**
    1. Lookup plate in Staff table (permanent access)
    2. If not found, lookup in Visitor table (time-limited access)
    3. If visitor, validate expiry date hasn't passed
    4. Use current vehicle status to auto-detect direction:
       - If status='OUT' → Grant ENTRY, set status='IN'
       - If status='IN' → Record EXIT, set status='OUT'
    5. Log all access attempts to audit trail
    
    **Smart Auto-Detection:**
    The system eliminates the need for manual IN/OUT selection by tracking
    the vehicle's current location status. This prevents human error and
    streamlines the access control process.
    
    Request Body:
        {
            \"plate_number\": str (required) - License plate detected by OCR
        }
        
    Returns:
        200 OK (Access Granted):
        {
            \"status\": \"ENTRY GRANTED\" | \"EXIT RECORDED\",
            \"message\": str (reason),
            \"name\": str (vehicle owner),
            \"plate_number\": str
        }
        
        200 OK (Access Denied):
        {
            \"status\": \"DENIED\",
            \"message\": str (denial reason),
            \"name\": str | \"Unknown\",
            \"plate_number\": str
        }
        
        400 Bad Request:
        {
            \"error\": \"Plate number required\"
        }
    
    **Denial Reasons:**
    - \"Unauthorized Vehicle - Not Registered\" - Plate not in database
    - \"Visitor access expired\" - Visitor's time window has passed
    
    **Access Logging:**
    All attempts (granted and denied) are logged to the access_log table
    for security auditing and compliance.
    """
    data = request.get_json()
    plate = data.get('plate_number', '').upper().strip()
    
    # Validate plate number is provided
    if not plate:
        return jsonify({'error': 'Plate number required'}), 400

    print(f"\\n[AUTH] Processing plate: '{plate}' (Smart Auto-Detection)")
    
    # Step 1: Check if vehicle is registered staff (optimized with indexed query)
    vehicle = Staff.query.filter_by(plate_number=plate).first()
    is_visitor = False
    vehicle_type = "Staff"
    
    # Step 2: If not staff, check visitor registry (also indexed)
    if not vehicle:
        vehicle = Visitor.query.filter_by(plate_number=plate).first()
        is_visitor = True
        vehicle_type = "Visitor"

    # Step 3: Deny access if plate not found in either registry
    if not vehicle:
        log_access('DENIED', plate, 'Unknown', 'Unauthorized Vehicle - Not Registered')
        return jsonify({
            'status': 'DENIED',
            'message': 'Unauthorized Vehicle - Not Registered',
            'name': 'Unknown',
            'plate_number': plate
        })

    timestamp = datetime.now(MALAYSIA_TZ)
    
    # Step 4: For visitors, validate access hasn't expired
    # (Fix timezone comparison for visitor expiry)
    if is_visitor and vehicle.expiry:
        # Convert visitor expiry to timezone-aware if it's naive
        if vehicle.expiry.tzinfo is None:
            visitor_expiry = vehicle.expiry.replace(tzinfo=MALAYSIA_TZ)
        else:
            visitor_expiry = vehicle.expiry
        
        # Deny if current time is past expiry
        if visitor_expiry < timestamp:
            log_access('DENIED', plate, vehicle.name, 'Visitor access expired')
            return jsonify({
                'status': 'DENIED',
                'message': 'Visitor access expired',
                'name': vehicle.name,
                'plate_number': plate
            })

    # Step 5: SMART AUTO-DETECTION - Determine direction based on current status
    # This eliminates need for manual IN/OUT button selection
    if vehicle.status == 'OUT':
        # Vehicle is currently outside → Grant ENTRY
        vehicle.status = 'IN'
        status = 'ENTRY GRANTED'
        reason = f'{vehicle_type} entering restricted area'
        print(f"✅ Auto-detected: Vehicle OUT → IN (Entry)")
    else:
        # Vehicle is currently inside → Record EXIT
        vehicle.status = 'OUT'
        status = 'EXIT RECORDED'
        reason = f'{vehicle_type} leaving restricted area'
        print(f"✅ Auto-detected: Vehicle IN → OUT (Exit)")
    
    # Commit status update to database
    db.session.commit()
    
    # Log this access event for audit trail
    log_access(status, plate, vehicle.name, reason)
    
    # Return success response
    return jsonify({
        'status': status,
        'message': reason,
        'name': vehicle.name,
        'plate_number': plate
    })


# ============================================================================
# API ENDPOINTS - AUDIT AND LOGGING
# ============================================================================

@app.route('/api/access-logs', methods=['GET'])
def get_access_logs():
    """
    Retrieve Recent Access Log History
    
    Returns the 50 most recent access attempts (both granted and denied)
    for security monitoring and auditing purposes.
    
    Returns:
        200 OK - JSON array of log objects:
        [
            {
                "timestamp": str (ISO 8601 format),
                "plate": str (license plate),
                "name": str (vehicle owner name),
                "status": str (ENTRY GRANTED | EXIT RECORDED | DENIED),
                "reason": str (detailed reason)
            },
            ...
        ]
        
    **Note:** Results are sorted by timestamp (newest first) and limited to
    50 records to prevent excessive data transfer.
    """
    # Query latest 50 logs, ordered by timestamp descending
    logs = AccessLog.query.order_by(AccessLog.timestamp.desc()).limit(50).all()
    
    # Format to JSON response
    return jsonify([{
        'timestamp': log.timestamp.isoformat(),
        'plate': log.plate_number,
        'name': log.name,
        'status': log.status,
        'reason': log.reason
    } for log in logs])

# ============================================================================
# API ENDPOINTS - OCR (LICENSE PLATE RECOGNITION)
# ============================================================================

@app.route('/api/ocr/scan', methods=['POST'])
def ocr_scan():
    """OCR.space - FREE OCR API"""
    print("=" * 60)
    print("[OCR] Scan request received")
    
    data = request.get_json()
    if not data or not data.get('image'):
        print("[OCR] ERROR: No image")
        return jsonify({'error': 'No image', 'message': 'Camera offline', 'text': 'NO_PLATE'}), 400
    
    try:
        # Extract base64 image data
        image_data = data.get('image')
        if ',' in image_data:
            image_data = image_data.split(',')[1]
        
        # OCR.space API
        ocr_api_key = os.getenv('OCR_SPACE_API_KEY', 'K87666639088957')
        
        print(f"[OCR] Sending to OCR.space...")
        response = requests.post(
            'https://api.ocr.space/parse/image',
            data={
                'apikey': ocr_api_key,
                'base64Image': f'data:image/jpeg;base64,{image_data}',
                'language': 'eng',
                'isOverlayRequired': False,
                'detectOrientation': True,
                'scale': True,
                'OCREngine': 2
            },
            timeout=30
        )
        
        result = response.json()
        
        if result.get('IsErroredOnProcessing'):
            print(f"[OCR] Error: {result.get('ErrorMessage')}")
            return jsonify({'error': 'OCR failed', 'message': 'No plate detected', 'text': 'NO_PLATE'}), 200
        
        # Extract text
        parsed_text = result.get('ParsedResults', [{}])[0].get('ParsedText', '').strip()
        
        # Clean and extract plate number (remove spaces, special chars)
        import re
        plate = re.sub(r'[^A-Z0-9]', '', parsed_text.upper())
        
        if plate and len(plate) >= 3:
            print(f"[OCR] ✅ Detected plate: {plate}")
            return jsonify({'success': True, 'text': plate, 'message': f'Detected: {plate}'}), 200
        else:
            print(f"[OCR] No valid plate found. Raw text: {parsed_text}")
            return jsonify({'success': False, 'text': 'NO_PLATE', 'message': 'No plate detected'}), 200
            
    except Exception as e:
        print(f"[OCR] ❌ EXCEPTION: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e), 'message': 'OCR error', 'text': 'NO_PLATE'}), 500


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def log_access(status, plate, name, reason):
    """
    Log a vehicle access attempt to the audit trail.
    
    Creates an immutable record in the access_log table for every vehicle
    access attempt, whether granted or denied. These logs are used for:
    - Security auditing
    - Compliance reporting
    - Historical tracking
    - Incident investigation
    
    Args:
        status (str): Access decision ('ENTRY GRANTED', 'EXIT RECORDED', 'DENIED')
        plate (str): License plate number detected/processed
        name (str): Vehicle owner name (or 'Unknown' if unregistered)
        reason (str): Detailed explanation for the access decision
        
    Returns:
        None (commits directly to database)
        
    Example:
        log_access('DENIED', 'ABC123', 'Unknown', 'Unauthorized Vehicle - Not Registered')
    """
    # Create new access log entry with current timestamp
    log = AccessLog(
        timestamp=datetime.now(MALAYSIA_TZ),
        plate_number=plate,
        name=name,
        status=status,
        reason=reason
    )
    db.session.add(log)
    db.session.commit()  # Immediate commit for audit integrity

# ============================================================================
# APPLICATION ENTRY POINT
# ============================================================================

if __name__ == '__main__':
    """
    Main application entry point.
    
    When run directly (not imported), this:
    1. Creates all database tables if they don't exist
    2. Starts the Flask development server on port 5000
    
    **Note:** For production, use a WSGI server like Gunicorn instead:
        gunicorn -w 4 -b 0.0.0.0:5000 app:app
    """
    # Initialize database schema
    with app.app_context():
        db.create_all()
    
    # Start development server
    app.run(debug=True, port=5000)