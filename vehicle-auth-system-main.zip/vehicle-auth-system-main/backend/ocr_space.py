"""
OCR.space FREE API - 25,000 requests/month
"""
import requests
import base64


def scan_with_ocr_space(image_data, api_key):
    """
    Use OCR.space FREE API to scan license plates
    
    Args:
        image_data: Base64 image data
        api_key: OCR.space API key
    
    Returns:
        dict with detected text
    """
    try:
        print("[OCR.space] Scanning image...")
        
        # Remove data URL prefix if present
        if image_data.startswith('data:'):
            image_data = image_data.split(',')[1]
        
        # OCR.space API endpoint
        url = "https://api.ocr.space/parse/image"
        
        payload = {
            'apikey': api_key,
            'base64Image': f'data:image/jpeg;base64,{image_data}',
            'language': 'eng',
            'isOverlayRequired': False,
            'detectOrientation': True,
            'scale': True,
            'OCREngine': 2  # Engine 2 is better for license plates
        }
        
        response = requests.post(url, data=payload, timeout=30)
        result = response.json()
        
        print(f"[OCR.space] Response: {result}")
        
        if result.get('IsErroredOnProcessing'):
            error = result.get('ErrorMessage', ['Unknown error'])[0]
            print(f"[OCR.space] ❌ Error: {error}")
            return {
                'text': 'NOPLATE',
                'message': f'OCR Error: {error}',
                'quality': 'ERROR'
            }
        
        # Extract text
        parsed_results = result.get('ParsedResults', [])
        if not parsed_results:
            print("[OCR.space] ⚠️ No text detected")
            return {
                'text': 'NOPLATE',
                'message': 'No plate visible',
                'quality': 'NONE'
            }
        
        detected_text = parsed_results[0].get('ParsedText', '').strip().upper()
        print(f"[OCR.space] Raw text: '{detected_text}'")
        
        # Clean: remove spaces, newlines, special chars
        plate = ''.join(c for c in detected_text if c.isalnum())
        
        if plate and 4 <= len(plate) <= 10:
            print(f"[OCR.space] ✅ SUCCESS: {plate}")
            return {
                'text': plate,
                'message': f'Detected: {plate}',
                'quality': 'DETECTED'
            }
        else:
            print(f"[OCR.space] ⚠️ Invalid plate length: {len(plate)}")
            return {
                'text': 'NOPLATE',
                'message': 'No valid plate detected',
                'quality': 'NONE'
            }
            
    except Exception as e:
        print(f"[OCR.space] ❌ Exception: {e}")
        import traceback
        traceback.print_exc()
        return {
            'text': 'NOPLATE',
            'message': f'OCR error: {str(e)}',
            'quality': 'ERROR'
        }
