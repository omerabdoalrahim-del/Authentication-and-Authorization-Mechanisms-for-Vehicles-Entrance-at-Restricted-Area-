"""Quick script to remove duplicate variable declarations from main.js"""
import re

# Read the file
with open('../frontend/js/main.js', 'r', encoding='utf-8') as f:
    content = f.read()

# Remove the two duplicate lines
content = content.replace("let isCameraRunning = false;\r\n", "")
content = content.replace("let videoStream = null;\r\n", "")

# Write back
with open('../frontend/js/main.js', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Fixed! Removed duplicate variables from main.js")
print("Now refresh your browser with Ctrl + Shift + F5")
