import sqlite3

DB_NAME = 'vehicle_data.db'

def create_initial_tables():
    """Creates the necessary staff and visitor tables."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # Staff Table: Permanent authorized users
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS staff (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            plate TEXT UNIQUE NOT NULL,
            status TEXT NOT NULL DEFAULT 'OUT' -- 'IN' or 'OUT'
        );
    """)
    
    # Visitor Table: Temporary authorized users
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS visitors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            plate TEXT UNIQUE NOT NULL,
            expiry TEXT NOT NULL, -- ISO 8601 string for expiration date/time
            status TEXT NOT NULL DEFAULT 'OUT' -- 'IN' or 'OUT'
        );
    """)
    
    conn.commit()
    conn.close()
    print(f"Database {DB_NAME} initialized successfully with staff and visitors tables.")

def add_test_data():
    """Adds initial test data for quick validation."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # Insert a test staff member
    try:
        cursor.execute("INSERT INTO staff (name, plate, status) VALUES (?, ?, ?)", 
                       ("Mentor's Car", "MNTR-001", "OUT"))
        print("Added Test Staff: MNTR-001")
    except sqlite3.IntegrityError:
        print("Test staff already exists.")

    # Insert a test visitor (expires far in the future)
    try:
        future_expiry = "2099-01-01T00:00"
        cursor.execute("INSERT INTO visitors (name, plate, expiry, status) VALUES (?, ?, ?, ?)",
                       ("Test Visitor", "VSTR-999", future_expiry, "OUT"))
        print("Added Test Visitor: VSTR-999")
    except sqlite3.IntegrityError:
        print("Test visitor already exists.")
        
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_initial_tables()
    add_test_data()
    
