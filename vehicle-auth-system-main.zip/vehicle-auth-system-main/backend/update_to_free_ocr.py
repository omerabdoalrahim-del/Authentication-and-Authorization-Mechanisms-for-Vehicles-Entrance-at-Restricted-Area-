# Script to update app.py with FREE OCR
import re

# Read current app.py
with open('app.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Remove requests import
content = content.replace('import requests\n', '')

# Add free_ocr import after the other imports
import_section = '''from dotenv import load_dotenv
import base64'''

new_import_section = '''from dotenv import load_dotenv
import base64

# ✅ FREE LOCAL OCR - NO COSTS!
from free_ocr import scan_license_plate_free'''

content = content.replace(import_section, new_import_section)

# Replace the entire ocr_scan function
# Find start of function
ocr_func_start = content.find('@app.route(\'/api/ocr/scan\'')
# Find the next function after it
next_func = content.find('\ndef log_access(', ocr_func_start)

# New FREE OCR function
new_ocr_func = '''@app.route('/api/ocr/scan', methods=['POST'])
def ocr_scan():
    """FREE LOCAL OCR - NO COSTS! Runs on your computer!"""
    print("=" * 60)
    print("[FREE OCR] Scan request received")
    
    data = request.get_json()
    if not data or not data.get('image'):
        print("[FREE OCR] ERROR: No image")
        return jsonify({'error': 'No image', 'message': 'Camera offline', 'text': 'NOPLATE'}), 400
    
    try:
        image_data = data['image']
        
        # Call FREE LOCAL OCR (no API, no cost!)
        result = scan_license_plate_free(image_data)
        
        return jsonify(result)
    
    except Exception as e:
        print("[FREE OCR] ❌ EXCEPTION: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e), 'message': 'OCR error', 'text': 'NOPLATE'}), 500

'''

# Replace old function with new
if ocr_func_start >= 0 and next_func >= 0:
    content = content[:ocr_func_start] + new_ocr_func + content[next_func:]

# Write updated app.py
with open('app.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ app.py updated with FREE OCR!")
