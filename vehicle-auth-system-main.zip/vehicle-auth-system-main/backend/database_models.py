"""
ORM Models mirroring EXISTING database tables
DO NOT MODIFY EXISTING FIELDS - Maps to current Supabase database
"""
from sqlalchemy import Column, Integer, String, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

Base = declarative_base()

# MIRRORS EXISTING: staff table
class Staff(Base):
    __tablename__ = "staff"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    plate = Column(String, unique=True, nullable=False, index=True)  # CRITICAL: Indexed for fast lookup
    status = Column(String, nullable=False, default='OUT')  # 'IN' or 'OUT'

# MIRRORS EXISTING: visitors table  
class Visitor(Base):
    __tablename__ = "visitor"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    plate = Column(String, unique=True, nullable=False, index=True)  # CRITICAL: Indexed
    expiry = Column(DateTime, nullable=False)
    status = Column(String, nullable=False, default='OUT')

# MIRRORS EXISTING: Access logs for audit trail
class AccessLog(Base):
    __tablename__ = "access_log"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False, index=True)
    plate_number = Column(String, nullable=False, index=True)
    name = Column(String)
    status = Column(String, nullable=False)  # 'GRANTED' or 'DENIED'
    reason = Column(String)
