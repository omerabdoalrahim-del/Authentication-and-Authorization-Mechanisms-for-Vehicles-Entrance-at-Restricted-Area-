"""Quick fix for OCR validation - reject short garbage results"""
import re

with open('app.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace the validation line
old_line = "if plate and len(plate) >= 3 and plate != 'NOPLATE':"
new_line = "if plate and plate != 'NOPLATE' and 4 <= len(plate) <= 10:"

content = content.replace(old_line, new_line)

# Also update the "No plate" message to show length
old_msg = 'print("[OPENROUTER OCR] ⚠️ No plate")'
new_msg = 'print(f"[OPENROUTER OCR] ⚠️ No valid plate (length: {len(plate) if plate else 0})")'

content = content.replace(old_msg, new_msg)

with open('app.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Fixed OCR validation - now requires 4-10 characters")
print("This will reject garbage like '100', '123', 'nadia'")
print("\nRestart backend: Ctrl+C then 'python app.py'")
