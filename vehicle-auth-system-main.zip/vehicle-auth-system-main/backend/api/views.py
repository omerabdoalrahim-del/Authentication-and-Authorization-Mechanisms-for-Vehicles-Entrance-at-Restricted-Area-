import json
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from .models import Staff, Visitor, AccessLog

@csrf_exempt
def vehicle_list(request):
    """
    Provides a list of all staff and visitor vehicles.
    """
    staff = list(Staff.objects.values().order_by('name'))
    visitors = list(Visitor.objects.values().order_by('name'))
    return JsonResponse({'staff': staff, 'visitors': visitors})

@csrf_exempt
def log_list(request):
    """
    Provides a list of all access logs.
    """
    logs = list(AccessLog.objects.values().order_by('-timestamp'))
    return JsonResponse(logs, safe=False)

@csrf_exempt
def staff_management(request, staff_id=None):
    """
    Manages adding and removing staff members.
    """
    if request.method == 'POST':
        data = json.loads(request.body)
        staff = Staff.objects.create(name=data['name'], plate=data['plate'].upper())
        return JsonResponse({'id': staff.id, 'name': staff.name, 'plate': staff.plate, 'status': staff.status}, status=201)

    if request.method == 'DELETE':
        try:
            staff = Staff.objects.get(id=staff_id)
            staff.delete()
            return HttpResponse(status=204)
        except Staff.DoesNotExist:
            return JsonResponse({'error': 'Staff not found'}, status=404)

@csrf_exempt
def visitor_management(request, visitor_id=None):
    """
    Manages adding and removing visitors.
    """
    if request.method == 'POST':
        data = json.loads(request.body)
        visitor = Visitor.objects.create(name=data['name'], plate=data['plate'].upper(), expiry=data['expiry'])
        return JsonResponse({'id': visitor.id, 'name': visitor.name, 'plate': visitor.plate, 'expiry': visitor.expiry, 'status': visitor.status}, status=201)

    if request.method == 'DELETE':
        try:
            visitor = Visitor.objects.get(id=visitor_id)
            visitor.delete()
            return HttpResponse(status=204)
        except Visitor.DoesNotExist:
            return JsonResponse({'error': 'Visitor not found'}, status=404)

@csrf_exempt
def process_vehicle(request):
    """
    Handles the logic for vehicle entry and exit.
    """
    if request.method == 'POST':
        data = json.loads(request.body)
        plate = data.get('plate', '').upper()
        direction = data.get('direction')
        timestamp = timezone.now()

        vehicle = Staff.objects.filter(plate=plate).first()
        vehicle_type = 'staff'
        if not vehicle:
            vehicle = Visitor.objects.filter(plate=plate).first()
            vehicle_type = 'visitor'

        def create_log_and_respond(status, reason, http_status=200):
            AccessLog.objects.create(plate=plate, name=vehicle.name if vehicle else 'Unknown', status=status, reason=reason, timestamp=timestamp)
            return JsonResponse({'status': status, 'reason': reason}, status=http_status)

        if not vehicle:
            return create_log_and_respond('DENIED', 'Unauthorized Vehicle.')

        if vehicle_type == 'visitor' and vehicle.expiry < timezone.now():
            return create_log_and_respond('DENIED', 'Visitor access has expired.')

        if direction == 'IN':
            if vehicle.status == 'IN':
                return create_log_and_respond('DENIED', 'Vehicle is already inside.')
            vehicle.status = 'IN'
            vehicle.save()
            return create_log_and_respond('ENTRY GRANTED', 'Vehicle entering restricted area.')

        if direction == 'OUT':
            if vehicle.status == 'OUT':
                return create_log_and_respond('DENIED', 'Vehicle is not found inside.')
            vehicle.status = 'OUT'
            vehicle.save()
            return create_log_and_respond('EXIT RECORDED', 'Vehicle leaving restricted area.')
            
    return JsonResponse({'error': 'Invalid request method'}, status=405)
