from django.db import models

class Staff(models.Model):
    name = models.CharField(max_length=255)
    plate = models.CharField(max_length=20, unique=True)
    status = models.CharField(max_length=3, choices=[('IN', 'In'), ('OUT', 'Out')], default='OUT')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.plate}"

class Visitor(models.Model):
    name = models.CharField(max_length=255)
    plate = models.CharField(max_length=20, unique=True)
    expiry = models.DateTimeField()
    status = models.CharField(max_length=3, choices=[('IN', 'In'), ('OUT', 'Out')], default='OUT')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.plate}"

class AccessLog(models.Model):
    plate = models.CharField(max_length=20)
    name = models.CharField(max_length=255)
    status = models.CharField(max_length=50)
    reason = models.CharField(max_length=255)
    timestamp = models.DateTimeField()

    def __str__(self):
        return f"{self.plate} at {self.timestamp} - {self.status}"
