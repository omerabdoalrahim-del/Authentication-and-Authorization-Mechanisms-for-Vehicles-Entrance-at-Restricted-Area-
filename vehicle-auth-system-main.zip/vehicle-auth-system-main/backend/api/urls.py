from django.urls import path
from . import views

urlpatterns = [
    path('vehicles/', views.vehicle_list, name='vehicle-list'),
    path('logs/', views.log_list, name='log-list'),
    path('staff/', views.staff_management, name='staff-add'),
    path('staff/<int:staff_id>/', views.staff_management, name='staff-remove'),
    path('visitors/', views.visitor_management, name='visitor-add'),
    path('visitors/<int:visitor_id>/', views.visitor_management, name='visitor-remove'),
    path('process/', views.process_vehicle, name='process-vehicle'),
]
