"""
Supabase Connection Diagnostic Tool
This script helps verify your Supabase database credentials
"""
import os
from dotenv import load_dotenv
import socket

load_dotenv()

print("=" * 60)
print("🔍 SUPABASE CONNECTION DIAGNOSTICS")
print("=" * 60)

# Get the DATABASE_URL
db_url = os.getenv('DATABASE_URL')
print(f"\n📋 DATABASE_URL from .env:")
print(f"{db_url}\n")

# Parse the connection string
if db_url:
    # Extract components
    if '@' in db_url:
        parts = db_url.split('@')
        credentials_part = parts[0]
        host_part = parts[1]
        
        # Extract host and port
        if ':' in host_part:
            host_and_db = host_part.split(':')
            if '/' in host_and_db[1]:
                port = host_and_db[1].split('/')[0]
                database = host_and_db[1].split('/')[1]
            else:
                port = host_and_db[1]
                database = "unknown"
            host = host_and_db[0]
        else:
            host = host_part.split('/')[0]
            port = "5432"
            database = host_part.split('/')[1] if '/' in host_part else "unknown"
        
        # Extract username from credentials
        if '://' in credentials_part:
            protocol = credentials_part.split('://')[0]
            user_pass = credentials_part.split('://')[1]
            if ':' in user_pass:
                username = user_pass.split(':')[0]
                password_masked = user_pass.split(':')[1][:3] + "***" + user_pass.split(':')[1][-2:]
            else:
                username = user_pass
                password_masked = "***"
        else:
            protocol = "unknown"
            username = "unknown"
            password_masked = "***"
        
        print("📊 Parsed Connection Details:")
        print(f"  Protocol: {protocol}")
        print(f"  Username: {username}")
        print(f"  Password: {password_masked}")
        print(f"  Host:     {host}")
        print(f"  Port:     {port}")
        print(f"  Database: {database}")
        
        # Test DNS resolution
        print(f"\n🌐 Testing DNS resolution for: {host}")
        try:
            ip_address = socket.gethostbyname(host)
            print(f"  ✅ SUCCESS! Resolved to: {ip_address}")
        except socket.gaierror as e:
            print(f"  ❌ FAILED! Cannot resolve hostname")
            print(f"  Error: {e}")
            print("\n⚠️  POSSIBLE ISSUES:")
            print("  1. Project reference might be incorrect")
            print("  2. Supabase project may be paused or deleted")
            print("  3. Network/DNS issues")
            print("  4. Check your Supabase dashboard for the correct connection string")
        except Exception as e:
            print(f"  ❌ ERROR: {e}")
        
        # Test port connectivity (if DNS works)
        try:
            print(f"\n🔌 Testing connection to {host}:{port}")
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((host, int(port)))
            sock.close()
            
            if result == 0:
                print(f"  ✅ Port {port} is OPEN and reachable!")
            else:
                print(f"  ❌ Port {port} is CLOSED or unreachable")
                print(f"  Error code: {result}")
        except Exception as e:
            print(f"  ⚠️  Could not test port: {e}")
    
    else:
        print("❌ Invalid DATABASE_URL format - missing '@' separator")
else:
    print("❌ No DATABASE_URL found in .env file")

print("\n" + "=" * 60)
print("💡 NEXT STEPS:")
print("=" * 60)
print("1. Go to your Supabase Dashboard: https://supabase.com/dashboard")
print("2. Select your project")
print("3. Go to: Project Settings > Database")
print("4. Find 'Connection string' section")
print("5. Copy the DIRECT connection string (NOT Session pooler)")
print("6. Update your .env file with the correct string")
print("\nFormat should be:")
print("postgresql+psycopg://postgres:[YOUR-PASSWORD]@db.[PROJECT-REF].supabase.co:5432/postgres")
print("=" * 60)
