import React from 'react';
import GateView from './components/GateView';
import './App.css';

function App() {
    return (
        <div className="app">
            <GateView />
        </div>
    );
}

export default App;
