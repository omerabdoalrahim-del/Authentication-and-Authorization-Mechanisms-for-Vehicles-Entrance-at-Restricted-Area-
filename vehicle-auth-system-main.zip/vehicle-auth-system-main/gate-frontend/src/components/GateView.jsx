import React, { useRef, useState, useEffect } from 'react';
import Webcam from 'react-webcam';
import axios from 'axios';
import './GateView.css';

function GateView() {
    const webcamRef = useRef(null);
    const [scanning, setScanning] = useState(false);
    const [result, setResult] = useState(null);
    const [showResult, setShowResult] = useState(false);

    useEffect(() => {
        // Auto-hide result after 5 seconds
        if (showResult) {
            const timer = setTimeout(() => {
                setShowResult(false);
                setResult(null);
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [showResult]);

    const captureAndCheck = async () => {
        // PHASE 4: Capture frame and send to API
        setScanning(true);
        setShowResult(false);

        try {
            // Capture current video frame as base64
            const imageSrc = webcamRef.current.getScreenshot();

            if (!imageSrc) {
                throw new Error('Failed to capture image');
            }

            console.log('[GATE] Image captured, converting to blob...');

            // Convert base64 to blob
            const response = await fetch(imageSrc);
            const blob = await response.blob();

            console.log('[GATE] Sending to API...');
            const startTime = Date.now();

            // Send to Phase 1 API
            const formData = new FormData();
            formData.append('file', blob, 'capture.jpg');

            const apiResponse = await axios.post('/api/gate/check-access', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            const latency = Date.now() - startTime;
            console.log(`[GATE] Response received in ${latency}ms`);

            // Display result
            setResult(apiResponse.data);
            setShowResult(true);

        } catch (error) {
            console.error('[GATE] Error:', error);
            setResult({
                status: 'DENIED',
                reason: 'System Error',
                owner: 'Unknown'
            });
            setShowResult(true);
        } finally {
            setScanning(false);
        }
    };

    return (
        <div className="gate-view">
            {/* Live Camera Feed */}
            <div className="camera-container">
                <Webcam
                    ref={webcamRef}
                    audio={false}
                    screenshotFormat="image/jpeg"
                    videoConstraints={{
                        width: 1920,
                        height: 1080,
                        facingMode: 'environment'
                    }}
                    className="webcam"
                />

                {/* Camera overlay */}
                <div className="camera-overlay">
                    <div className="header">
                        <h1>🚗 SecureGate Live</h1>
                        <div className="status-indicator">ONLINE</div>
                    </div>

                    <div className="capture-zone">
                        <div className="frame-guide">
                            <div className="corner top-left"></div>
                            <div className="corner top-right"></div>
                            <div className="corner bottom-left"></div>
                            <div className="corner bottom-right"></div>
                            <p>Position license plate within frame</p>
                        </div>
                    </div>

                    <div className="controls">
                        <button
                            onClick={captureAndCheck}
                            disabled={scanning}
                            className="capture-button"
                        >
                            {scanning ? (
                                <>
                                    <div className="spinner"></div>
                                    <span>SCANNING...</span>
                                </>
                            ) : (
                                <>
                                    <span className="camera-icon">📸</span>
                                    <span>CAPTURE & CHECK</span>
                                </>
                            )}
                        </button>
                    </div>
                </div>
            </div>

            {/* Full-Screen Access Result Overlay */}
            {showResult && result && (
                <div className={`result-overlay ${result.status === 'GRANTED' ? 'granted' : 'denied'}`}>
                    <div className="result-content">
                        {result.status === 'GRANTED' ? (
                            <>
                                <div className="icon">✓</div>
                                <h1 className="status">ACCESS GRANTED</h1>
                                <div className="details">
                                    <p className="owner">{result.owner}</p>
                                    <p className="type">{result.vehicle_type}</p>
                                    <p className="plate">{result.plate}</p>
                                </div>
                            </>
                        ) : (
                            <>
                                <div className="icon">✗</div>
                                <h1 className="status">ACCESS DENIED</h1>
                                <div className="details">
                                    <p className="reason">{result.reason}</p>
                                    {result.owner && result.owner !== 'Unknown' && (
                                        <p className="owner-denied">{result.owner}</p>
                                    )}
                                    {result.detected_text && (
                                        <p className="detected">Detected: {result.detected_text}</p>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default GateView;
