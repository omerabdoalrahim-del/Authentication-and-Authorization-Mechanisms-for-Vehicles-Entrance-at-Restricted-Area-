// app.js - Corrected and Optimized for non-seizing OCR

const API_BASE = 'http://127.0.0.1:5000/api';
// Expose last scanned plate globally for dashboard.html to use
window.lastScannedPlate = ''; 

// --- OCR SETUP ---
let tesseractWorker = null;
async function getWorker(){
  if (tesseractWorker) return tesseractWorker;
  // Initialize worker with logger muted to avoid spam and improve performance
  tesseractWorker = Tesseract.createWorker({ logger: m => { /* console.log(m) */ } });
  await tesseractWorker.load();
  await tesseractWorker.loadLanguage('eng');
  await tesseractWorker.initialize('eng');
  await tesseractWorker.setParameters({
    tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-', // Restrict characters for better accuracy
    preserve_interword_spaces: '0'
  });
  return tesseractWorker;
}

// --- CAMERA & OCR LOGIC ---
const videoEl = document.getElementById('cameraPreview');
let _cameraIntervalRef = null;

async function processFrame() {
    if (!videoEl || videoEl.paused || videoEl.ended) return;

    // Use a small canvas to minimize the data sent to the worker
    const offscreenCanvas = document.createElement('canvas');
    const ctx = offscreenCanvas.getContext('2d');
    offscreenCanvas.width = 320;
    offscreenCanvas.height = 240;
    ctx.drawImage(videoEl, 0, 0, 320, 240);

    const worker = await getWorker();

    try {
        // Run OCR
        const { data: { text } } = await worker.recognize(offscreenCanvas);
        
        // Clean and normalize the plate text
        const detectedPlate = (text || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').trim();

        if (detectedPlate.length >= 4 && detectedPlate !== window.lastScannedPlate) {
            window.lastScannedPlate = detectedPlate;
            // Update the UI in dashboard.html
            const capturedPlateEl = document.getElementById('capturedPlate');
            if (capturedPlateEl) {
                capturedPlateEl.textContent = detectedPlate;
                capturedPlateEl.classList.remove('hidden');
                document.getElementById('cameraText').classList.add('hidden');
            }
        }
    } catch (e) {
        console.warn('OCR error:', e);
    }
}

async function startCameraAuto() {
  if (!videoEl) {
    console.error('startCameraAuto: #cameraPreview not found');
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    videoEl.srcObject = stream;
    videoEl.play();
    
    // Use an interval to periodically run the OCR, but make it slow to avoid seizing
    // A 4-second interval is more resource-friendly than continuous processing.
    if (_cameraIntervalRef) clearInterval(_cameraIntervalRef);
    _cameraIntervalRef = setInterval(processFrame, 4000); 

  } catch (e) {
    console.error('Could not access camera/video stream:', e);
  }
}

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    // Check if Tesseract is available (it should be loaded in dashboard.html)
    if (typeof Tesseract !== 'undefined') {
        startCameraAuto();
    } else {
        console.error('Tesseract.js not loaded. Check dashboard.html script loading.');
    }
});

// Clean up worker on page unload
window.addEventListener('beforeunload', async () => {
  if (_cameraIntervalRef) clearInterval(_cameraIntervalRef);
  if (tesseractWorker) {
    try { await tesseractWorker.terminate(); } catch(e) {}
    tesseractWorker = null;
  }
});

// A helper for testing access (Not strictly needed, but useful for app.js)
window.testAccess = async (plate, direction) => {
    const result = await fetch(`${API_BASE}/process-vehicle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plate_number: plate, direction })
    }).then(r => r.json());
    console.log(`Access check for ${plate} (${direction}):`, result);
    return result;
};