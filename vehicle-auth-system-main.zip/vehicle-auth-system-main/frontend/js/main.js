// Vehicle Management and Data Loading
// Note: Camera functionality is in camera.js

// State
let currentTab = 'staff';

// DOM Elements
const staffTableBody = document.getElementById('staffTableBody');
const visitorTableBody = document.getElementById('visitorTableBody');
const accessLogContainer = document.getElementById('accessLogContainer');
const staffContent = document.getElementById('staffContent');
const visitorContent = document.getElementById('visitorContent');
const staffTab = document.getElementById('staffTab');
const visitorTab = document.getElementById('visitorTab');

// Tab Switching
window.switchTab = (tab) => {
    currentTab = tab;
    if (tab === 'staff') {
        staffContent.classList.remove('hidden');
        visitorContent.classList.add('hidden');
        staffTab.classList.add('border-blue-500', 'text-blue-600');
        staffTab.classList.remove('border-transparent', 'text-gray-500');
        visitorTab.classList.remove('border-blue-500', 'text-blue-600');
        visitorTab.classList.add('border-transparent', 'text-gray-500');
        loadStaff();
    } else {
        visitorContent.classList.remove('hidden');
        staffContent.classList.add('hidden');
        visitorTab.classList.add('border-blue-500', 'text-blue-600');
        visitorTab.classList.remove('border-transparent', 'text-gray-500');
        staffTab.classList.remove('border-blue-500', 'text-blue-600');
        staffTab.classList.add('border-transparent', 'text-gray-500');
        loadVisitors();
    }
};

// Load Staff Vehicles
async function loadStaff() {
    try {
        staffTableBody.innerHTML = '<tr><td colspan="4" class="px-6 py-4 text-center text-gray-500">Loading...</td></tr>';
        const staff = await window.api.getStaff();
        staffTableBody.innerHTML = '';

        if (staff.length === 0) {
            staffTableBody.innerHTML = '<tr><td colspan="4" class="px-6 py-4 text-center text-gray-500">No staff vehicles registered</td></tr>';
            return;
        }

        staff.forEach(s => {
            const row = `
        <tr class="hover:bg-gray-50">
          <td class="py-3 px-4 text-sm">${s.name}</td>
          <td class="py-3 px-4 text-sm font-mono font-bold">${s.plate}</td>
          <td class="py-3 px-4 text-sm">
            <span class="px-2 py-1 rounded text-xs font-semibold ${s.status === 'IN' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}">
              ${s.status}
            </span>
          </td>
          <td class="py-3 px-4 text-sm">
            <button onclick="deleteStaffVehicle(${s.id})" 
                    class="text-red-600 hover:text-red-800 font-medium">
              Delete
            </button>
          </td>
        </tr>
      `;
            staffTableBody.innerHTML += row;
        });
    } catch (error) {
        console.error('Error loading staff:', error);
        staffTableBody.innerHTML = '<tr><td colspan="4" class="px-6 py-4 text-center text-red-500">Error loading data</td></tr>';
    }
}

// Load Visitor Vehicles
async function loadVisitors() {
    try {
        visitorTableBody.innerHTML = '<tr><td colspan="5" class="px-6 py-4 text-center text-gray-500">Loading...</td></tr>';
        const visitors = await window.api.getVisitors();
        visitorTableBody.innerHTML = '';

        if (visitors.length === 0) {
            visitorTableBody.innerHTML = '<tr><td colspan="5" class="px-6 py-4 text-center text-gray-500">No visitor vehicles registered</td></tr>';
            return;
        }

        visitors.forEach(v => {
            const expiry = new Date(v.expiry);
            const isExpired = expiry < new Date();
            const row = `
        <tr class="hover:bg-gray-50">
          <td class="py-3 px-4 text-sm">${v.name}</td>
          <td class="py-3 px-4 text-sm font-mono font-bold">${v.plate}</td>
          <td class="py-3 px-4 text-sm">${expiry.toLocaleString('en-MY', { timeZone: 'Asia/Kuala_Lumpur', hour12: true })}</td>
          <td class="py-3 px-4 text-sm">
            <span class="px-2 py-1 rounded text-xs font-semibold ${v.status === 'IN' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}">
              ${v.status}
            </span>
          </td>
          <td class="py-3 px-4 text-sm">
            <button onclick="deleteVisitorVehicle(${v.id})" 
                    class="text-red-600 hover:text-red-800 font-medium">
              Delete
            </button>
          </td>
        </tr>
      `;
            visitorTableBody.innerHTML += row;
        });
    } catch (error) {
        console.error('Error loading visitors:', error);
        visitorTableBody.innerHTML = '<tr><td colspan="5" class="px-6 py-4 text-center text-red-500">Error loading data</td></tr>';
    }
}

// Load Access Logs
async function loadLogs() {
    try {
        const logs = await window.api.getLogs();
        accessLogContainer.innerHTML = '';

        if (logs.length === 0) {
            accessLogContainer.innerHTML = '<div class="text-center text-gray-500 py-10 text-sm">No access logs yet</div>';
            return;
        }

        logs.forEach(log => {
            const timestamp = new Date(log.timestamp).toLocaleString('en-MY', {
                timeZone: 'Asia/Kuala_Lumpur',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: true
            });

            // Color coding: Green for ENTRY, Blue for EXIT, Red for DENIED
            let statusColor, textColor;
            if (log.status.includes('EXIT')) {
                statusColor = 'border-blue-500 bg-blue-50';
                textColor = 'text-blue-600';
            } else if (log.status.includes('GRANTED')) {
                statusColor = 'border-green-500 bg-green-50';
                textColor = 'text-green-600';
            } else {
                statusColor = 'border-red-500 bg-red-50';
                textColor = 'text-red-600';
            }

            const item = `
        <div class="border-l-4 ${statusColor} p-3 rounded-r">
          <div class="flex justify-between items-start mb-1">
            <span class="font-mono font-bold text-sm">${log.plate}</span>
            <span class="text-xs text-gray-500">${timestamp}</span>
          </div>
          <div class="text-sm font-medium">${log.name || 'Unknown'}</div>
          <div class="text-xs text-gray-600">${log.reason}</div>
          <div class="text-xs font-semibold mt-1 ${textColor}">
            ${log.status}
          </div>
        </div>
      `;
            accessLogContainer.innerHTML += item;
        });
    } catch (error) {
        console.error('Error loading logs:', error);
    }
}

// Delete Staff Vehicle
window.deleteStaffVehicle = async (id) => {
    if (!confirm('Are you sure you want to delete this vehicle?')) return;
    try {
        await window.api.deleteStaff(id);
        loadStaff();
    } catch (error) {
        alert('Error deleting vehicle');
    }
};

// Delete Visitor Vehicle
window.deleteVisitorVehicle = async (id) => {
    if (!confirm('Are you sure you want to delete this vehicle?')) return;
    try {
        await window.api.deleteVisitor(id);
        loadVisitors();
    } catch (error) {
        alert('Error deleting vehicle');
    }
};

// Form Handlers
document.getElementById('addStaffForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('staffName').value;
    const plate = document.getElementById('staffPlate').value;

    try {
        const result = await window.api.addStaff(name, plate);
        if (result.success) {
            document.getElementById('addStaffForm').reset();
            loadStaff();
            alert('Staff vehicle added successfully');
        } else {
            alert(result.error || 'Failed to add staff vehicle');
        }
    } catch (error) {
        alert('Error adding staff vehicle');
    }
});

document.getElementById('addVisitorForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('visitorName').value;
    const plate = document.getElementById('visitorPlate').value;
    const expiry = document.getElementById('visitorExpiry').value;

    try {
        const result = await window.api.addVisitor(name, plate, expiry);
        if (result.success) {
            document.getElementById('addVisitorForm').reset();
            loadVisitors();
            alert('Visitor vehicle added successfully');
        } else {
            alert(result.error || 'Failed to add visitor vehicle');
        }
    } catch (error) {
        alert('Error adding visitor vehicle');
    }
});

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing Vehicle Management System...');
    loadStaff();
    loadLogs();
    // Refresh logs every 1 second for fast traffic flow
    setInterval(loadLogs, 1000);
});
