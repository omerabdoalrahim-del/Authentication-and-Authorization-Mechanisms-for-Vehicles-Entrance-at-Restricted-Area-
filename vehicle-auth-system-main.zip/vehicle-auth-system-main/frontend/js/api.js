// API connection to backend
// Use relative URL to avoid CORS issues between localhost and 127.0.0.1
const API_BASE = '/api';

window.api = {
    // Staff endpoints
    async getStaff() {
        const res = await fetch(`${API_BASE}/staff`);
        return await res.json();
    },

    async addStaff(name, plate_number) {
        const res = await fetch(`${API_BASE}/staff`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, plate_number })
        });
        return await res.json();
    },

    async deleteStaff(id) {
        const res = await fetch(`${API_BASE}/staff/${id}`, { method: 'DELETE' });
        return await res.json();
    },

    // Visitor endpoints
    async getVisitors() {
        const res = await fetch(`${API_BASE}/visitors`);
        return await res.json();
    },

    async addVisitor(name, plate_number, expiry) {
        const res = await fetch(`${API_BASE}/visitors`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, plate_number, expiry })
        });
        return await res.json();
    },

    async deleteVisitor(id) {
        const res = await fetch(`${API_BASE}/visitors/${id}`, { method: 'DELETE' });
        return await res.json();
    },

    // Process vehicle
    async processVehicle(plate_number, direction) {
        const res = await fetch(`${API_BASE}/process-vehicle`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ plate_number, direction })
        });
        return await res.json();
    },

    // Get access logs
    async getLogs() {
        const res = await fetch(`${API_BASE}/access-logs`);
        return await res.json();
    },

    // OCR scan
    async scanPlate(imageData) {
        const res = await fetch(`${API_BASE}/ocr/scan`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image: imageData })
        });
        return await res.json();
    }
};
