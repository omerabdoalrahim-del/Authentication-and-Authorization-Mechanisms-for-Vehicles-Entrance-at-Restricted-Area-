// Camera and OCR handling
let isCameraRunning = false;
let videoStream = null;
let autoScanInterval = null;
let isProcessing = false;

// Get DOM elements
const startCameraBtn = document.getElementById('startCameraBtn');
const stopCameraBtn = document.getElementById('stopCameraBtn');
const manualEntryBtn = document.getElementById('manualEntryBtn');
const manualEntrySection = document.getElementById('manualEntrySection');
const manualPlateInput = document.getElementById('manualPlateInput');
const cameraVideo = document.getElementById('cameraVideo');
const cameraOff = document.getElementById('cameraOff');
const statusDisplay = document.getElementById('statusDisplay');

// Start Camera Button
startCameraBtn.addEventListener('click', async () => {
    try {
        videoStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment', width: 1280, height: 720 }
        });

        cameraVideo.srcObject = videoStream;
        cameraVideo.classList.remove('hidden');
        cameraOff.classList.add('hidden');

        startCameraBtn.classList.add('hidden');
        stopCameraBtn.classList.remove('hidden');

        isCameraRunning = true;
        statusDisplay.textContent = 'Camera active - Auto-scanning enabled';
        statusDisplay.classList.add('bg-green-100', 'text-green-700');
        statusDisplay.classList.remove('bg-gray-100', 'text-gray-700');

        console.log('✅ Camera started - Auto-scan every 3 seconds');

        // Start auto-scanning every 3 seconds
        autoScanInterval = setInterval(() => {
            if (isCameraRunning && !isProcessing) {
                captureAndProcess();
            }
        }, 3000);

    } catch (err) {
        console.error('Camera error:', err);
        alert('Could not access camera. Please check permissions or use Manual Entry.');
    }
});

// Stop Camera Button
stopCameraBtn.addEventListener('click', () => {
    // Stop auto-scanning
    if (autoScanInterval) {
        clearInterval(autoScanInterval);
        autoScanInterval = null;
    }

    if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
        videoStream = null;
    }

    cameraVideo.classList.add('hidden');
    cameraOff.classList.remove('hidden');

    stopCameraBtn.classList.add('hidden');
    startCameraBtn.classList.remove('hidden');

    isCameraRunning = false;
    statusDisplay.textContent = 'Camera stopped';
    statusDisplay.classList.remove('bg-green-100', 'text-green-700');
    statusDisplay.classList.add('bg-gray-100', 'text-gray-700');

    console.log('Camera stopped');
});

// Manual Entry Button
manualEntryBtn.addEventListener('click', () => {
    if (manualEntrySection.classList.contains('hidden')) {
        manualEntrySection.classList.remove('hidden');
        manualPlateInput.focus();
    } else {
        manualEntrySection.classList.add('hidden');
    }
});

// Manual Plate Input - Press Enter
manualPlateInput.addEventListener('keypress', async (e) => {
    if (e.key === 'Enter') {
        const plate = manualPlateInput.value.trim().toUpperCase();
        if (!plate) {
            alert('Please enter a plate number');
            return;
        }

        statusDisplay.textContent = `Processing ${plate}...`;
        statusDisplay.classList.add('bg-blue-100', 'text-blue-700');

        await processVehicle(plate);

        manualPlateInput.value = '';
        manualEntrySection.classList.add('hidden');
    }
});

// Capture and process camera frame
async function captureAndProcess() {
    if (!isCameraRunning || isProcessing) return;

    isProcessing = true;

    try {
        // Create canvas
        const canvas = document.createElement('canvas');
        canvas.width = cameraVideo.videoWidth;
        canvas.height = cameraVideo.videoHeight;

        if (canvas.width === 0 || canvas.height === 0) {
            isProcessing = false;
            return;
        }

        const ctx = canvas.getContext('2d');
        ctx.drawImage(cameraVideo, 0, 0);

        const imageData = canvas.toDataURL('image/jpeg', 0.8);

        console.log('📸 Capturing snapshot for OCR...');
        statusDisplay.textContent = 'Scanning...';
        statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-blue-100 text-blue-700';

        // Send to OCR
        const response = await fetch('/api/ocr/scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image: imageData })
        });

        const result = await response.json();

        if (result.text && result.text !== 'NO_PLATE' && result.text.length >= 3) {
            console.log(`✅ Plate detected: ${result.text}`);
            await processVehicle(result.text);
        } else {
            console.log('No plate detected');
            statusDisplay.textContent = 'Camera active - Auto-scanning enabled';
            statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-green-100 text-green-700';
        }

    } catch (error) {
        console.error('OCR error:', error);
        statusDisplay.textContent = 'Camera active - Auto-scanning enabled';
        statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-green-100 text-green-700';
    } finally {
        isProcessing = false;
    }
}

// Process vehicle (send to backend)
async function processVehicle(plateNumber) {
    try {
        console.log(`🚗 Processing plate: ${plateNumber}`);

        const response = await fetch('/api/process-vehicle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ plate_number: plateNumber })
        });

        const result = await response.json();
        console.log('Result:', result);

        // Update status display
        if (result.status && result.status.includes('GRANTED')) {
            statusDisplay.textContent = `✅ ${result.status} - ${result.name}`;
            statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-green-100 text-green-700';
        } else if (result.status && result.status.includes('EXIT')) {
            statusDisplay.textContent = `🚪 ${result.status} - ${result.name}`;
            statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-blue-100 text-blue-700';
        } else {
            statusDisplay.textContent = `❌ ${result.message || 'Access Denied'}`;
            statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-red-100 text-red-700';
        }

        // Reload data
        if (typeof loadStaff === 'function') loadStaff();
        if (typeof loadVisitors === 'function') loadVisitors();
        if (typeof loadLogs === 'function') loadLogs();

        // Reset after 3 seconds
        setTimeout(() => {
            if (isCameraRunning) {
                statusDisplay.textContent = 'Camera active - Auto-scanning enabled';
                statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-green-100 text-green-700';
            } else {
                statusDisplay.textContent = 'Ready to scan';
                statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-gray-100 text-gray-700';
            }
        }, 3000);

    } catch (error) {
        console.error('Error processing vehicle:', error);
        statusDisplay.textContent = '❌ Error processing vehicle';
        statusDisplay.className = 'mb-4 text-center text-lg font-semibold p-4 rounded-md bg-red-100 text-red-700';
    }
}
