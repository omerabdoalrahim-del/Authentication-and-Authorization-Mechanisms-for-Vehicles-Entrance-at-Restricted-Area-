/**
 * Vehicle Authentication System - Frontend Configuration
 * 
 * This file contains the client-side configuration for connecting to the
 * Supabase backend database. The configuration is exposed as a global variable
 * for use across all frontend JavaScript modules.
 * 
 * @module config
 * @author Vehicle Authentication System Team
 * @created 2025
 */

// ============================================================================
// SUPABASE CLIENT CONFIGURATION
// ============================================================================

/**
 * Supabase Configuration Object
 * 
 * Contains the connection details for the Supabase backend:
 * - URL: The unique Supabase project URL
 * - anonKey: Public anonymous key for client-side requests
 * 
 * **Security Note:**
 * The anon key is safe to expose in client-side code. It only allows
 * operations permitted by Row Level Security (RLS) policies set in Supabase.
 * Sensitive operations require authentication or are protected by RLS.
 * 
 * @type {Object}
 * @property {string} url - Supabase project URL
 * @property {string} anonKey - Supabase anonymous/public API key
 */
window.SUPABASE_CONFIG = {
    url: 'https://zrojirkuiukrdnbsbokk.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inpyb2ppcmt1aXVrcmRuYnNib2trIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM4MjIxNjEsImV4cCI6MjA3OTM5ODE2MX0.p8DM4Q7vRswC3MMuOwQvSxhZ6ihTuslo4qez-L72hJw'
};

/**
 * Usage Example:
 * 
 * Import this configuration in other files by including config.js first:
 * <script src="js/config.js"></script>
 * <script src="js/api.js"></script>
 * 
 * Then access the configuration:
 * const { url, anonKey } = window.SUPABASE_CONFIG;
 */
