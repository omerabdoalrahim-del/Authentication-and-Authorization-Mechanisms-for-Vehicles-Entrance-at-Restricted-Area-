// --- DATA STORAGE (Using localStorage) ---
let staff = [];
let visitors = [];
let accessLogs = [];
let isSimulationRunning = false;

// --- LOCALSTORAGE HELPERS ---
const STAFF_KEY = 'anpr_staff_list';
const VISITORS_KEY = 'anpr_visitor_list';

function saveToStorage() {
    localStorage.setItem(STAFF_KEY, JSON.stringify(staff));
    localStorage.setItem(VISITORS_KEY, JSON.stringify(visitors));
    console.log('Data saved to localStorage');
}

function loadFromStorage() {
    const storedStaff = localStorage.getItem(STAFF_KEY);
    const storedVisitors = localStorage.getItem(VISITORS_KEY);
    staff = storedStaff ? JSON.parse(storedStaff) : [];
    visitors = storedVisitors ? JSON.parse(storedVisitors) : [];
    console.log('Data loaded from localStorage');
}

// --- HELPER ELEMENTS ---
const cameraTextEl = document.getElementById('cameraText');
const capturedPlateEl = document.getElementById('capturedPlate');
const gateStatusTextEl = document.getElementById('gateStatusText');
const gateIndicatorEl = document.getElementById('gateIndicator');
const gateStatusEl = document.getElementById('gateStatus');

// --- HELPERS ---
function normalizePlate(s) {
    return (s || '').toString().toUpperCase().trim().replace(/[^A-Z0-9-]/g, '');
}

function nowISO() {
    return new Date().toISOString();
}

function setGateState(status, message) {
    const s = (status || '').toString().toLowerCase();
    if (gateStatusEl) gateStatusEl.className = 'mt-4 flex items-center p-4 rounded-md';

    let indicatorClass = 'w-6 h-6 rounded-full mr-4';
    let statusBgClass = 'bg-gray-200';
    let indicatorColorClass = 'bg-gray-400';

    if (s === 'granted' || s === 'entry granted') {
        statusBgClass = 'bg-green-100';
        indicatorColorClass = 'bg-green-500';
    } else if (s === 'denied') {
        statusBgClass = 'bg-red-100';
        indicatorColorClass = 'bg-red-500';
    } else if (s === 'processing' || s === 'exit') {
        statusBgClass = 'bg-yellow-100';
        indicatorColorClass = 'bg-yellow-500 animate-pulse';
    }

    if (gateStatusEl) gateStatusEl.classList.add(statusBgClass);
    if (gateIndicatorEl) gateIndicatorEl.className = indicatorClass + ' ' + indicatorColorClass;
    if (gateStatusTextEl) gateStatusTextEl.textContent = message || status || '';
}

// --- UI RENDERING ---
function renderStaffTable() {
    const tableBody = document.getElementById('staffTableBody');
    tableBody.innerHTML = '';
    staff.forEach(person => {
        const statusClass = person.status === 'IN' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';
        const row = `
            <tr class="hover:bg-gray-50">
                <td class="py-3 px-4 text-sm text-gray-900">${person.name}</td>
                <td class="py-3 px-4 text-sm text-gray-500 font-mono">${person.plate.toUpperCase()}</td>
                <td class="py-3 px-4 text-sm">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">
                        ${person.status}
                    </span>
                </td>
                <td class="py-3 px-4">
                    <button onclick="removeStaff(${person.id})" class="text-red-600 hover:text-red-800 text-sm font-medium">Remove</button>
                </td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
    if (staff.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="4" class="text-center py-4 text-gray-500">No staff vehicles registered.</td></tr>`;
    }
}

function renderVisitorTable() {
    const tableBody = document.getElementById('visitorTableBody');
    tableBody.innerHTML = '';
    visitors.forEach(visitor => {
        const expiryDate = new Date(visitor.expiry);
        const isExpired = expiryDate < new Date();
        const formattedDate = expiryDate.toLocaleString();
        const statusClass = visitor.status === 'IN' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';
        const row = `
            <tr class="hover:bg-gray-50">
                <td class="py-3 px-4 text-sm text-gray-900">${visitor.name}</td>
                <td class="py-3 px-4 text-sm text-gray-500 font-mono">${visitor.plate.toUpperCase()}</td>
                <td class="py-3 px-4 text-sm ${isExpired ? 'text-red-500' : 'text-gray-500'}">${formattedDate} ${isExpired ? '(Expired)' : ''}</td>
                <td class="py-3 px-4 text-sm">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">
                        ${visitor.status}
                    </span>
                </td>
                <td class="py-3 px-4">
                    <button onclick="removeVisitor(${visitor.id})" class="text-red-600 hover:text-red-800 text-sm font-medium">Remove</button>
                </td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
    if (visitors.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="5" class="text-center py-4 text-gray-500">No visitor vehicles registered.</td></tr>`;
    }
}

function renderAccessLogs() {
    const logContainer = document.getElementById('accessLogContainer');
    logContainer.innerHTML = '';
    [...accessLogs].reverse().forEach(log => {
        const statusColors = {
            'ENTRY GRANTED': 'text-green-600 border-green-200 bg-green-50',
            'EXIT RECORDED': 'text-blue-600 border-blue-200 bg-blue-50',
            'DENIED': 'text-red-600 border-red-200 bg-red-50'
        };
        const logElement = `
            <div class="p-3 rounded-md border ${statusColors[log.status] || 'text-gray-600 border-gray-200 bg-gray-50'}">
                <div class="flex justify-between items-center">
                    <p class="font-semibold text-sm">${log.name} <span class="font-mono text-gray-600">(${log.plate.toUpperCase()})</span></p>
                    <p class="text-xs text-gray-500">${new Date(log.timestamp).toLocaleTimeString()}</p>
                </div>
                <p class="text-sm mt-1">Status: <span class="font-bold ${statusColors[log.status] || ''}">${log.status}</span> - ${log.reason}</p>
            </div>
        `;
        logContainer.innerHTML += logElement;
    });
    if (accessLogs.length === 0) {
        logContainer.innerHTML = `<p class="text-center text-gray-500 mt-4">No access attempts logged yet.</p>`;
    }
}

// --- EVENT HANDLERS ---
document.getElementById('addStaffForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.getElementById('staffName').value;
    const plate = document.getElementById('staffPlate').value.toUpperCase();
    if (name && plate) {
        const newId = staff.length > 0 ? Math.max(...staff.map(s => s.id)) + 1 : 1;
        staff.push({ id: newId, name, plate: normalizePlate(plate), status: 'OUT' });
        renderStaffTable();
        saveToStorage();
        this.reset();
    }
});

document.getElementById('addVisitorForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.getElementById('visitorName').value;
    const plate = document.getElementById('visitorPlate').value.toUpperCase();
    const expiry = document.getElementById('visitorExpiry').value;
    if (name && plate && expiry) {
        const newId = visitors.length > 0 ? Math.max(...visitors.map(v => v.id)) + 1 : 1;
        visitors.push({ id: newId, name, plate: normalizePlate(plate), expiry: new Date(expiry).toISOString(), status: 'OUT' });
        renderVisitorTable();
        saveToStorage();
        this.reset();
    }
});

window.removeStaff = function (id) {
    staff = staff.filter(person => person.id !== id);
    renderStaffTable();
    saveToStorage();
}

window.removeVisitor = function (id) {
    visitors = visitors.filter(visitor => visitor.id !== id);
    renderVisitorTable();
    saveToStorage();
}

window.switchTab = function (tab) {
    const staffTab = document.getElementById('staffTab');
    const visitorTab = document.getElementById('visitorTab');
    const staffContent = document.getElementById('staffContent');
    const visitorContent = document.getElementById('visitorContent');

    if (tab === 'staff') {
        staffTab.classList.add('border-blue-500', 'text-blue-600');
        staffTab.classList.remove('border-transparent', 'text-gray-500');
        visitorTab.classList.add('border-transparent', 'text-gray-500');
        visitorTab.classList.remove('border-blue-500', 'text-blue-600');
        staffContent.classList.remove('hidden');
        visitorContent.classList.add('hidden');
    } else {
        visitorTab.classList.add('border-blue-500', 'text-blue-600');
        visitorTab.classList.remove('border-transparent', 'text-gray-500');
        staffTab.classList.add('border-transparent', 'text-gray-500');
        staffTab.classList.remove('border-blue-500', 'text-blue-600');
        visitorContent.classList.remove('hidden');
        staffContent.classList.add('hidden');
    }
}

// --- SIMULATION ---
function runSimulation(plate) {
    if (isSimulationRunning) return;
    isSimulationRunning = true;

    const entryButton = document.getElementById('simulateEntryBtn');
    const exitButton = document.getElementById('simulateExitBtn');
    entryButton.disabled = true;
    exitButton.disabled = true;
    entryButton.classList.add('opacity-50', 'cursor-not-allowed');
    exitButton.classList.add('opacity-50', 'cursor-not-allowed');

    cameraTextEl.classList.add('hidden');
    capturedPlateEl.textContent = 'Scanning...';
    capturedPlateEl.classList.remove('hidden');
    setGateState('processing', 'Vehicle detected. Capturing plate...');

    setTimeout(() => {
        capturedPlateEl.textContent = plate;
        setTimeout(() => {
            processPlate(plate);
        }, 1500);
    }, 2000);
}

window.simulateVehicleEntry = function () {
    const vehiclesOut = [...staff, ...visitors].filter(v => v.status === 'OUT').map(v => v.plate);
    const platesToSimulate = [...vehiclesOut, 'UNKN-123'];
    if (platesToSimulate.length === 0) {
        showTemporaryMessage("No vehicles are available to simulate entry.", "denied");
        return;
    }
    const randomPlate = platesToSimulate[Math.floor(Math.random() * platesToSimulate.length)];
    runSimulation(randomPlate);
}

window.simulateVehicleExit = function () {
    const vehiclesIn = [...staff, ...visitors].filter(v => v.status === 'IN');
    if (vehiclesIn.length === 0) {
        showTemporaryMessage("No vehicles are currently inside to simulate an exit.", "denied");
        return;
    }
    const platesIn = vehiclesIn.map(v => v.plate);
    const randomPlate = platesIn[Math.floor(Math.random() * platesIn.length)];
    runSimulation(randomPlate);
}

function showTemporaryMessage(message, type) {
    if (type === 'denied') {
        setGateState('denied', message);
    } else {
        setGateState('processing', message);
    }
    setTimeout(resetGateStatus, 3000);
}

function processPlate(rawPlate) {
    const plate = normalizePlate(rawPlate);
    if (!plate) {
        resetGateStatus();
        return;
    }

    cameraTextEl?.classList.add('hidden');
    if (capturedPlateEl) {
        capturedPlateEl.textContent = plate;
        capturedPlateEl.classList.remove('hidden');
    }
    setGateState('processing', `Authenticating ${plate}...`);

    setTimeout(() => {
        const timestamp = nowISO();
        let vehicle = null;
        let vehicleType = 'Unknown';

        let staffVehicle = staff.find(s => normalizePlate(s.plate) === plate);
        if (staffVehicle) {
            vehicle = staffVehicle;
            vehicleType = 'Staff';
        } else {
            let visitorVehicle = visitors.find(v => normalizePlate(v.plate) === plate);
            if (visitorVehicle) {
                vehicle = visitorVehicle;
                vehicleType = 'Visitor';
            }
        }

        let status, reason;

        if (!vehicle) {
            status = 'DENIED';
            reason = 'Unauthorized or unregistered plate.';
        } else if (vehicleType === 'Visitor' && new Date(vehicle.expiry) < new Date()) {
            status = 'DENIED';
            reason = 'Visitor access has expired.';
        } else {
            if (vehicle.status === 'OUT') {
                vehicle.status = 'IN';
                status = 'ENTRY GRANTED';
                reason = 'Vehicle entering restricted area.';
                setGateState('granted', 'Access Granted. Opening Gate for Entry.');
            } else {
                vehicle.status = 'OUT';
                status = 'EXIT RECORDED';
                reason = 'Vehicle leaving restricted area.';
                setGateState('exit', 'Exit Confirmed. Closing Gate.');
            }
            saveToStorage();
        }

        addLog(plate, vehicle ? vehicle.name : 'Unknown', status, reason, timestamp);

        if (status === 'DENIED') {
            setGateState('denied', 'Access Denied.');
            if (capturedPlateEl) {
                capturedPlateEl.textContent = vehicle ? status : 'UNREGISTERED';
                setTimeout(() => {
                    capturedPlateEl.classList.add('hidden');
                    cameraTextEl?.classList.remove('hidden');
                }, 1800);
            }
        }

        renderStaffTable();
        renderVisitorTable();
        renderAccessLogs();
        setTimeout(resetGateStatus, 3500);
    }, 700);
}

function addLog(plate, name, status, reason, timestamp) {
    accessLogs.push({ timestamp, plate, name, status, reason });
    if (accessLogs.length > 100) {
        accessLogs.shift();
    }
}

function resetGateStatus() {
    if (isSimulationRunning) {
        gateStatusEl.className = 'mt-4 flex items-center p-4 rounded-md bg-gray-200';
        gateIndicatorEl.className = 'w-6 h-6 rounded-full bg-gray-400 mr-4';
        gateStatusTextEl.textContent = 'Gate is Closed';

        cameraTextEl.classList.remove('hidden');
        capturedPlateEl.classList.add('hidden');

        const entryButton = document.getElementById('simulateEntryBtn');
        const exitButton = document.getElementById('simulateExitBtn');
        entryButton.disabled = false;
        exitButton.disabled = false;
        entryButton.classList.remove('opacity-50', 'cursor-not-allowed');
        exitButton.classList.remove('opacity-50', 'cursor-not-allowed');
        isSimulationRunning = false;
    }
}

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    loadFromStorage();
    renderStaffTable();
    renderVisitorTable();
    renderAccessLogs();

    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    now.setHours(now.getHours() + 1);
    document.getElementById('visitorExpiry').value = now.toISOString().slice(0, 16);
});
