import React, { useState } from 'react';
import axios from 'axios';

function VehicleRegistrationForm({ onVehicleAdded }) {
    const [formData, setFormData] = useState({
        plateNumber: '',
        ownerName: '',
        vehicleType: 'STAFF',
        expiryDate: ''
    });
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleInputChange = (e) => {
        const { name, value } = e.target;

        // CRITICAL: Force uppercase and strip whitespace for plate number
        if (name === 'plateNumber') {
            const sanitized = value.toUpperCase().replace(/\s+/g, '');
            setFormData(prev => ({
                ...prev,
                [name]: sanitized
            }));
        } else {
            setFormData(prev => ({
                ...prev,
                [name]: value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setMessage('');

        // Validation
        if (!formData.plateNumber || !formData.ownerName) {
            setError('Plate number and owner name are required');
            return;
        }

        if (formData.vehicleType === 'VISITOR' && !formData.expiryDate) {
            setError('Expiry date is required for visitors');
            return;
        }

        try {
            const response = await axios.post('/api/admin/vehicle/register', {
                plate_number: formData.plateNumber, // Already sanitized by input handler
                owner_name: formData.ownerName,
                vehicle_type: formData.vehicleType,
                expiry_date: formData.expiryDate || null
            });

            setMessage(`✓ ${response.data.message}: ${formData.plateNumber}`);

            // Reset form
            setFormData({
                plateNumber: '',
                ownerName: '',
                vehicleType: 'STAFF',
                expiryDate: ''
            });

            // Notify parent component
            onVehicleAdded();

            // Clear success message after 3 seconds
            setTimeout(() => setMessage(''), 3000);

        } catch (error) {
            setError(error.response?.data?.detail || 'Failed to register vehicle');
            setTimeout(() => setError(''), 5000);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="registration-form">
            <div className="form-row">
                <div className="form-group">
                    <label htmlFor="plateNumber">Plate Number *</label>
                    <input
                        type="text"
                        id="plateNumber"
                        name="plateNumber"
                        value={formData.plateNumber}
                        onChange={handleInputChange}
                        placeholder="ABC1234"
                        required
                        style={{ fontFamily: 'monospace', fontWeight: 'bold' }}
                    />
                    <small style={{ color: '#666' }}>
                        Auto-sanitized: uppercase, no spaces
                    </small>
                </div>

                <div className="form-group">
                    <label htmlFor="ownerName">Owner Name *</label>
                    <input
                        type="text"
                        id="ownerName"
                        name="ownerName"
                        value={formData.ownerName}
                        onChange={handleInputChange}
                        placeholder="John Doe"
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="vehicleType">Vehicle Type *</label>
                    <select
                        id="vehicleType"
                        name="vehicleType"
                        value={formData.vehicleType}
                        onChange={handleInputChange}
                        required
                    >
                        <option value="STAFF">Staff (Permanent)</option>
                        <option value="VISITOR">Visitor (Temporary)</option>
                    </select>
                </div>

                {formData.vehicleType === 'VISITOR' && (
                    <div className="form-group">
                        <label htmlFor="expiryDate">Expiry Date *</label>
                        <input
                            type="datetime-local"
                            id="expiryDate"
                            name="expiryDate"
                            value={formData.expiryDate}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                )}
            </div>

            {message && (
                <div className="success-message">{message}</div>
            )}

            {error && (
                <div className="error-message">{error}</div>
            )}

            <button type="submit" className="btn btn-success" style={{ marginTop: '1.5rem', width: 'auto', minWidth: '200px', fontSize: '1rem', padding: '0.75rem 1.5rem' }}>
                ✓ Add Vehicle
            </button>
        </form>
    );
}

export default VehicleRegistrationForm;
