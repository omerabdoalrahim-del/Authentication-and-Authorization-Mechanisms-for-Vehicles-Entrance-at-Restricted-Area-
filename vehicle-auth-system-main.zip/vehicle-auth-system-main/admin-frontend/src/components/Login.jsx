import React, { useState } from 'react';
import './Login.css';

function Login({ onLogin }) {
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const ADMIN_PASSWORD = 'admin123'; // In production, use backend auth

    const handleSubmit = (e) => {
        e.preventDefault();

        if (password === ADMIN_PASSWORD) {
            onLogin();
        } else {
            setError('Invalid password');
            setTimeout(() => setError(''), 3000);
        }
    };

    return (
        <div className="login-container">
            <div className="login-card">
                <div className="login-header">
                    <h1>🔐 SecureGate Admin</h1>
                    <p>Vehicle Authentication System</p>
                </div>

                <form onSubmit={handleSubmit} className="login-form">
                    <div className="form-group">
                        <label htmlFor="password">Admin Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Enter admin password"
                            required
                        />
                    </div>

                    {error && <div className="error-message">{error}</div>}

                    <button type="submit" className="btn btn-primary btn-block">
                        Login
                    </button>
                </form>

                <div className="login-footer">
                    <small>Default password: admin123</small>
                </div>
            </div>
        </div>
    );
}

export default Login;
