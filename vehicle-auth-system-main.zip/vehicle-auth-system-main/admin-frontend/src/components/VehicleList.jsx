import React from 'react';
import axios from 'axios';

function VehicleList({ vehicles, type, onVehicleDeleted }) {
    const handleDelete = async (vehicleId, plate) => {
        if (!window.confirm(`Are you sure you want to revoke access for ${plate}?`)) {
            return;
        }

        try {
            await axios.delete(`/api/admin/vehicle/${vehicleId}?vehicle_type=${type}`);
            alert(`✓ Vehicle ${plate} removed successfully`);
            onVehicleDeleted();
        } catch (error) {
            alert(`Failed to delete vehicle: ${error.response?.data?.detail || error.message}`);
        }
    };

    if (vehicles.length === 0) {
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: '#999' }}>
                No {type.toLowerCase()} vehicles registered
            </div>
        );
    }

    return (
        <table className="table">
            <thead>
                <tr>
                    <th>Plate Number</th>
                    <th>Owner</th>
                    <th>Status</th>
                    {type === 'VISITOR' && <th>Expires</th>}
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {vehicles.map((vehicle) => (
                    <tr key={vehicle.id}>
                        <td style={{ fontFamily: 'monospace', fontWeight: 'bold' }}>
                            {vehicle.plate}
                        </td>
                        <td>{vehicle.owner}</td>
                        <td>
                            <span className={`badge badge-${vehicle.status.toLowerCase()}`}>
                                {vehicle.status}
                            </span>
                        </td>
                        {type === 'VISITOR' && (
                            <td>
                                {new Date(vehicle.expiry).toLocaleString()}
                            </td>
                        )}
                        <td>
                            <button
                                onClick={() => handleDelete(vehicle.id, vehicle.plate)}
                                className="btn btn-danger"
                                style={{ fontSize: '12px', padding: '6px 12px' }}
                            >
                                Revoke Access
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
}

export default VehicleList;
