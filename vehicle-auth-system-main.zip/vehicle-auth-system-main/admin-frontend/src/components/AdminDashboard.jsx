import React, { useState, useEffect } from 'react';
import axios from 'axios';
import VehicleRegistrationForm from './VehicleRegistrationForm';
import VehicleList from './VehicleList';
import './AdminDashboard.css';

function AdminDashboard({ onLogout }) {
    const [vehicles, setVehicles] = useState({ staff: [], visitors: [] });
    const [loading, setLoading] = useState(true);

    const fetchVehicles = async () => {
        try {
            const response = await axios.get('/api/admin/vehicles/all');
            setVehicles(response.data);
            setLoading(false);
        } catch (error) {
            console.error('Error fetching vehicles:', error);
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchVehicles();
    }, []);

    const handleVehicleAdded = () => {
        fetchVehicles(); // Refresh list
    };

    const handleVehicleDeleted = () => {
        fetchVehicles(); // Refresh list
    };

    return (
        <div className="dashboard">
            <div className="dashboard-header">
                <h1>🚗 SecureGate Admin Dashboard</h1>
                <button onClick={onLogout} className="btn btn-danger">
                    Logout
                </button>
            </div>

            <div className="container">
                {/* Registration Form */}
                <div className="card">
                    <h2>📝 Vehicle Registration</h2>
                    <VehicleRegistrationForm onVehicleAdded={handleVehicleAdded} />
                </div>

                {/* Vehicle Management Lists */}
                <div className="card">
                    <h2>📋 Vehicle Management</h2>

                    {loading ? (
                        <p>Loading vehicles...</p>
                    ) : (
                        <>
                            <div className="vehicle-section">
                                <h3>Staff Vehicles ({vehicles.staff.length})</h3>
                                <VehicleList
                                    vehicles={vehicles.staff}
                                    type="STAFF"
                                    onVehicleDeleted={handleVehicleDeleted}
                                />
                            </div>

                            <div className="vehicle-section">
                                <h3>Visitor Vehicles ({vehicles.visitors.length})</h3>
                                <VehicleList
                                    vehicles={vehicles.visitors}
                                    type="VISITOR"
                                    onVehicleDeleted={handleVehicleDeleted}
                                />
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}

export default AdminDashboard;
